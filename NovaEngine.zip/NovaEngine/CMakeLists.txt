cmake_minimum_required(VERSION 3.20)
project(NovaEngine C CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
include(FetchContent)

set(SDL_TEST OFF CACHE BOOL "" FORCE)
if(ANDROID)
  set(SDL_SHARED ON CACHE BOOL "" FORCE); set(SDL_STATIC OFF CACHE BOOL "" FORCE)
else()
  set(SDL_SHARED OFF CACHE BOOL "" FORCE); set(SDL_STATIC ON CACHE BOOL "" FORCE)
endif()

FetchContent_Declare(SDL2 GIT_REPOSITORY https://github.com/libsdl-org/SDL.git GIT_TAG release-2.30.9 GIT_SHALLOW TRUE)
FetchContent_Declare(glm GIT_REPOSITORY https://github.com/g-truc/glm.git GIT_TAG 1.0.1 GIT_SHALLOW TRUE)
FetchContent_Declare(imgui GIT_REPOSITORY https://github.com/ocornut/imgui.git GIT_TAG v1.91.5-docking GIT_SHALLOW TRUE SOURCE_SUBDIR _none)
FetchContent_Declare(imguizmo GIT_REPOSITORY https://github.com/CedricGuillemet/ImGuizmo.git GIT_TAG master GIT_SHALLOW TRUE SOURCE_SUBDIR _none)
FetchContent_Declare(miniaudio GIT_REPOSITORY https://github.com/mackron/miniaudio.git GIT_TAG 0.11.21 GIT_SHALLOW TRUE SOURCE_SUBDIR _none)
FetchContent_Declare(tinygltf GIT_REPOSITORY https://github.com/syoyo/tinygltf.git GIT_TAG v2.9.3 GIT_SHALLOW TRUE SOURCE_SUBDIR _none)
FetchContent_Declare(stb GIT_REPOSITORY https://github.com/nothings/stb.git GIT_TAG master GIT_SHALLOW TRUE SOURCE_SUBDIR _none)
FetchContent_MakeAvailable(SDL2 glm imgui imguizmo miniaudio tinygltf stb)

set(SDL_TGT SDL2-static)
if(ANDROID)
  set(SDL_TGT SDL2)
endif()

add_library(imgui_lib STATIC
  ${imgui_SOURCE_DIR}/imgui.cpp ${imgui_SOURCE_DIR}/imgui_draw.cpp
  ${imgui_SOURCE_DIR}/imgui_tables.cpp ${imgui_SOURCE_DIR}/imgui_widgets.cpp
  ${imgui_SOURCE_DIR}/imgui_demo.cpp
  ${imgui_SOURCE_DIR}/backends/imgui_impl_sdl2.cpp
  ${imgui_SOURCE_DIR}/backends/imgui_impl_opengl3.cpp
  ${imguizmo_SOURCE_DIR}/ImGuizmo.cpp)
target_include_directories(imgui_lib PUBLIC ${imgui_SOURCE_DIR} ${imgui_SOURCE_DIR}/backends ${imguizmo_SOURCE_DIR})
target_link_libraries(imgui_lib PUBLIC ${SDL_TGT})
if(ANDROID)
  target_compile_definitions(imgui_lib PUBLIC IMGUI_IMPL_OPENGL_ES3)
endif()

set(SRC src/main.cpp src/Editor.cpp src/Assets.cpp src/Audio.cpp
        src/Physics.cpp src/Animation.cpp src/ScriptManager.cpp)
if(ANDROID)
  add_library(main SHARED ${SRC}); set(APP main)
else()
  add_executable(NovaEditor ${SRC}); set(APP NovaEditor)
endif()

target_include_directories(${APP} PRIVATE src ${miniaudio_SOURCE_DIR} ${tinygltf_SOURCE_DIR} ${stb_SOURCE_DIR})
# Para compilar los scripts del usuario en caliente
target_compile_definitions(${APP} PRIVATE NOVA_CXX="${CMAKE_CXX_COMPILER}" NOVA_INC="${CMAKE_SOURCE_DIR}/src")
target_link_libraries(${APP} PRIVATE imgui_lib glm::glm ${CMAKE_DL_LIBS})
if(ANDROID)
  target_link_libraries(${APP} PRIVATE SDL2 GLESv3 log android)
else()
  find_package(Threads REQUIRED)
  target_link_libraries(${APP} PRIVATE SDL2main SDL2-static Threads::Threads)
endif()
