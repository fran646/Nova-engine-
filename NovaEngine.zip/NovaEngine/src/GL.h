#pragma once
#ifdef __ANDROID__
  #include <GLES3/gl3.h>
  inline bool LoadGL(){ return true; }
#else
  #include <SDL.h>
  #include <SDL_opengl.h>
  #define GL_FUNCS(X) \
    X(CreateShader,CREATESHADER) X(ShaderSource,SHADERSOURCE) X(CompileShader,COMPILESHADER) \
    X(GetShaderiv,GETSHADERIV) X(GetShaderInfoLog,GETSHADERINFOLOG) X(CreateProgram,CREATEPROGRAM) \
    X(AttachShader,ATTACHSHADER) X(LinkProgram,LINKPROGRAM) X(GetProgramiv,GETPROGRAMIV) \
    X(GetProgramInfoLog,GETPROGRAMINFOLOG) X(DeleteShader,DELETESHADER) X(UseProgram,USEPROGRAM) \
    X(GetUniformLocation,GETUNIFORMLOCATION) X(UniformMatrix4fv,UNIFORMMATRIX4FV) \
    X(Uniform1i,UNIFORM1I) X(Uniform1f,UNIFORM1F) X(Uniform3f,UNIFORM3F) X(Uniform4f,UNIFORM4F) \
    X(GenVertexArrays,GENVERTEXARRAYS) X(BindVertexArray,BINDVERTEXARRAY) X(DeleteVertexArrays,DELETEVERTEXARRAYS) \
    X(GenBuffers,GENBUFFERS) X(BindBuffer,BINDBUFFER) X(BufferData,BUFFERDATA) X(DeleteBuffers,DELETEBUFFERS) \
    X(EnableVertexAttribArray,ENABLEVERTEXATTRIBARRAY) X(VertexAttribPointer,VERTEXATTRIBPOINTER) \
    X(GenFramebuffers,GENFRAMEBUFFERS) X(BindFramebuffer,BINDFRAMEBUFFER) X(FramebufferTexture2D,FRAMEBUFFERTEXTURE2D) \
    X(CheckFramebufferStatus,CHECKFRAMEBUFFERSTATUS) X(GenRenderbuffers,GENRENDERBUFFERS) \
    X(BindRenderbuffer,BINDRENDERBUFFER) X(RenderbufferStorage,RENDERBUFFERSTORAGE) \
    X(FramebufferRenderbuffer,FRAMEBUFFERRENDERBUFFER) X(ActiveTexture,ACTIVETEXTURE) X(GenerateMipmap,GENERATEMIPMAP)
  #define X(n,N) inline PFNGL##N##PROC gl##n = nullptr;
  GL_FUNCS(X)
  #undef X
  inline bool LoadGL(){
    #define X(n,N) gl##n = (PFNGL##N##PROC)SDL_GL_GetProcAddress("gl" #n); if(!gl##n) return false;
    GL_FUNCS(X)
    #undef X
    return true;
  }
#endif
