#pragma once
#include <string>
namespace Audio {
  bool Init();
  void Shutdown();
  int  Play(const std::string& path, bool loop, float volume);  // returns voice id or -1
  void Stop(int id);
  void StopAll();
  void Update();  // frees finished one-shot sounds
}
