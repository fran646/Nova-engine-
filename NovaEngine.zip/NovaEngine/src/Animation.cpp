#include "Animation.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>

namespace Anim {
const char* PropName(int p) {
  static const char* n[] = { "Posición", "Rotación", "Escala", "Color" };
  return p >= 0 && p < 4 ? n[p] : "?";
}
Track& Ensure(AnimClip& c, int prop) {
  for (auto& t : c.tracks) if (t.prop == prop) return t;
  Track t; t.prop = prop; c.tracks.push_back(t); return c.tracks.back();
}
void InsertKey(Track& tr, float t, glm::vec4 v, int ease) {
  for (auto& k : tr.keys) if (std::abs(k.t - t) < 1e-4f) { k.v = v; k.ease = ease; return; }
  Key k; k.t = t; k.v = v; k.ease = ease;
  tr.keys.push_back(k);
  std::sort(tr.keys.begin(), tr.keys.end(), [](const Key& a, const Key& b) { return a.t < b.t; });
}
bool Sample(const AnimClip& c, float t, int prop, glm::vec4& out) {
  for (auto& tr : c.tracks) {
    if (tr.prop != prop || tr.keys.empty()) continue;
    const auto& k = tr.keys;
    if (t <= k.front().t) { out = k.front().v; return true; }
    if (t >= k.back().t)  { out = k.back().v;  return true; }
    for (size_t i = 0; i + 1 < k.size(); i++) {
      if (t >= k[i].t && t < k[i + 1].t) {
        const Key& a = k[i]; const Key& b = k[i + 1];
        float f = (t - a.t) / std::max(b.t - a.t, 1e-6f);
        if (a.ease == 2) f = 0.f;
        else if (a.ease == 1) f = f * f * (3.f - 2.f * f);
        out = glm::mix(a.v, b.v, f); return true;
      }
    }
  }
  return false;
}
bool Load(const std::string& path, AnimClip& out) {
  std::ifstream i(path); std::string magic;
  if (!(i >> magic) || magic != "NOVAANIM") return false;
  i >> out.duration; out.tracks.clear();
  std::string kw;
  while (i >> kw) {
    if (kw != "track") continue;
    int p = 0, n = 0; i >> p >> n;
    Track tr; tr.prop = p;
    for (int k = 0; k < n; k++) {
      std::string kk; Key key;
      i >> kk >> key.t >> key.v.x >> key.v.y >> key.v.z >> key.v.w >> key.ease;
      tr.keys.push_back(key);
    }
    out.tracks.push_back(tr);
  }
  return true;
}
bool Save(const AnimClip& c, const std::string& path) {
  std::ofstream o(path); if (!o) return false;
  o << std::setprecision(9) << "NOVAANIM 1 " << c.duration << "\n";
  for (auto& tr : c.tracks) {
    o << "track " << tr.prop << ' ' << tr.keys.size() << "\n";
    for (auto& k : tr.keys)
      o << "key " << k.t << ' ' << k.v.x << ' ' << k.v.y << ' ' << k.v.z << ' ' << k.v.w << ' ' << k.ease << "\n";
  }
  return true;
}
}
