#pragma once
// API pública para scripts del usuario (Scripts/*.cpp).
// Cada script se compila a una librería dinámica separada. Sólo se recompila cuando el .cpp cambia.
struct NovaScriptCtx {
  float* pos; float* rot; float* scl; float* color; float* param; float* vel;
  float dt;        // segundos desde el último frame
  float time;      // tiempo total desde Play
  int entityId;
  int grounded;    // 1 si el objeto con Rigidbody toca algo por abajo
};
struct NovaScript {
  const char* name;
  void (*update)(NovaScriptCtx*);
  void (*start)(NovaScriptCtx*);
};
#ifdef _WIN32
  #define NOVA_EXPORT __declspec(dllexport)
#else
  #define NOVA_EXPORT __attribute__((visibility("default")))
#endif
// Uso:  NOVA_SCRIPT("Nombre", [](NovaScriptCtx* c) { c->rot[1] += 90 * c->dt; })
#define NOVA_SCRIPT(NAME, ...) \
  extern "C" NOVA_EXPORT NovaScript* nova_script() { \
    static NovaScript s{ NAME, +__VA_ARGS__, nullptr }; return &s; }
