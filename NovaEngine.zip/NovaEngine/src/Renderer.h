#pragma once
#include "Gfx.h"
#include "Scene.h"
#include "Assets.h"
#include <algorithm>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

struct Renderer {
  Shader sh; Mesh grid;
  GLint lM, lVP, lCol, lUnlit, lLD, lLC, lAmb, lTex;

  void Init() {
    const char* vs = R"(
layout(location=0) in vec3 aP; layout(location=1) in vec3 aN; layout(location=2) in vec2 aUV;
uniform mat4 uM; uniform mat4 uVP; out vec3 vN; out vec2 vUV;
void main(){ vec4 w=uM*vec4(aP,1.0); vN=transpose(inverse(mat3(uM)))*aN; vUV=aUV; gl_Position=uVP*w; })";
    const char* fs = R"(
in vec3 vN; in vec2 vUV; out vec4 o;
uniform sampler2D uTex; uniform vec4 uCol; uniform vec3 uLD; uniform vec3 uLC; uniform vec3 uAmb; uniform float uUnlit;
void main(){
  vec4 t=texture(uTex,vUV)*uCol; if(t.a<0.01) discard;
  vec3 n=normalize(vN); if(!gl_FrontFacing) n=-n;
  float d=max(dot(n,-normalize(uLD)),0.0);
  vec3 lit=t.rgb*(uAmb+uLC*d);
  o=vec4(mix(lit,t.rgb,uUnlit),t.a); })";
    sh.Build(vs, fs);
    lM = sh.U("uM"); lVP = sh.U("uVP"); lCol = sh.U("uCol"); lUnlit = sh.U("uUnlit");
    lLD = sh.U("uLD"); lLC = sh.U("uLC"); lAmb = sh.U("uAmb"); lTex = sh.U("uTex");
    std::vector<Vertex> v; std::vector<uint32_t> i;
    for (int k = -20; k <= 20; k++) {
      float f = (float)k; uint32_t b = (uint32_t)v.size();
      v.push_back({ {f,0,-20}, {0,1,0}, {0,0} }); v.push_back({ {f,0,20}, {0,1,0}, {0,0} });
      v.push_back({ {-20,0,f}, {0,1,0}, {0,0} }); v.push_back({ {20,0,f}, {0,1,0}, {0,0} });
      for (uint32_t j = 0; j < 4; j++) i.push_back(b + j);
    }
    grid.Create(v, i, GL_LINES);
  }

  void DrawMesh(const Mesh* m, const glm::mat4& w, const Texture& t, const glm::vec4& c, float unlit) {
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, t.id);
    glUniformMatrix4fv(lM, 1, GL_FALSE, glm::value_ptr(w));
    glUniform4f(lCol, c.x, c.y, c.z, c.w); glUniform1f(lUnlit, unlit); m->Draw();
  }

  void Draw(Scene& s, Assets& a, const glm::mat4& view, const glm::mat4& proj, bool editor) {
    glEnable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glClearColor(.16f, .17f, .20f, 1); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram(sh.id);
    glm::mat4 vp = proj * view; glUniformMatrix4fv(lVP, 1, GL_FALSE, glm::value_ptr(vp));
    glUniform1i(lTex, 0);
    glm::vec3 ld = glm::normalize(glm::vec3(-.4f, -1.f, -.3f)), lc(1.0f);
    for (auto& x : s.e) if (x.active && x.hasLight) {
      ld = glm::normalize(glm::mat3(s.World(x)) * glm::vec3(0, 0, -1)); lc = x.lightColor * x.intensity; break;
    }
    glUniform3f(lLD, ld.x, ld.y, ld.z); glUniform3f(lLC, lc.x, lc.y, lc.z); glUniform3f(lAmb, .28f, .28f, .3f);
    if (editor) {
      glUniformMatrix4fv(lM, 1, GL_FALSE, glm::value_ptr(glm::mat4(1))); glBindTexture(GL_TEXTURE_2D, a.white.id);
      glUniform4f(lCol, .45f, .45f, .5f, 1); glUniform1f(lUnlit, 1); grid.Draw();
    }

    glm::vec3 camPos = glm::vec3(glm::inverse(view)[3]);
    struct Sp { float d; Entity* e; }; std::vector<Sp> sprites;
    for (auto& x : s.e) {
      if (!x.active) continue; glm::mat4 w = s.World(x);
      if (x.hasMesh) {
        Model* md = a.GetModel(x.mesh);
        if (md) for (size_t k = 0; k < md->subs.size(); k++) {
          const SubMesh& sm = md->subs[k];
          std::string tn = (k < x.subTex.size() && !x.subTex[k].empty()) ? x.subTex[k]
                         : (!x.tex.empty() ? x.tex : sm.tex);
          DrawMesh(sm.mesh.get(), w, a.GetTex(tn), x.color, 0);
        }
      }
      if (x.hasSprite) sprites.push_back({ glm::length(glm::vec3(w[3]) - camPos), &x });
      if (editor && !x.hasMesh && !x.hasSprite && (x.hasCamera || x.hasLight)) {
        glm::vec4 c = x.hasCamera ? glm::vec4(.3f, .6f, 1, 1) : glm::vec4(1, .9f, .3f, 1);
        DrawMesh(a.Prim("Cube"), w * glm::scale(glm::mat4(1), glm::vec3(.3f)), a.white, c, 1);
      }
      if (editor && x.hasCollider && !x.hasMesh) {    // contorno del collider en el editor
        glm::vec4 c(.2f, 1.f, .4f, 1.f);
        glm::mat4 cw = w * glm::scale(glm::mat4(1), x.colKind == 1 ? glm::vec3(x.colRadius * 2) : x.colSize);
        DrawMesh(a.Prim(x.colKind == 1 ? "Sphere" : "Cube"), cw, a.white, c * glm::vec4(1, 1, 1, .25f), 1);
      }
    }
    std::sort(sprites.begin(), sprites.end(), [](const Sp& p, const Sp& q) { return p.d > q.d; });
    for (auto& sp : sprites) {
      Entity& x = *sp.e; Texture& t = a.GetTex(x.sprite);
      float sx = x.sprite.empty() ? 1.f : t.w / 100.f, sy = x.sprite.empty() ? 1.f : t.h / 100.f;
      DrawMesh(a.Prim("Quad"), s.World(x) * glm::scale(glm::mat4(1), glm::vec3(sx, sy, 1)), t, x.sprColor, 1);
    }
  }
};
