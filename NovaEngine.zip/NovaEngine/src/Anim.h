#pragma once
#include <glm/glm.hpp>
#include <glm/gtc/quaternion.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <functional>

struct TRS { glm::vec3 t{0}; glm::quat r{1, 0, 0, 0}; glm::vec3 s{1}; };
struct Channel { int node = -1, path = 0, interp = 0; std::vector<float> times; std::vector<glm::vec4> vals; }; // path 0=T 1=R 2=S ; interp 0 lin 1 step
struct Clip { std::string name; float dur = 0; std::vector<Channel> ch; };
struct Skin {
  std::vector<int> joints, parent; std::vector<glm::mat4> ibm; std::vector<TRS> rest; std::vector<Clip> clips;
};
struct AnimState {   // per-entity animator (skeletal)
  bool has = false, loop = true, playOnStart = true, preview = false, run = false;
  std::string clip, prevClip; float speed = 1, fadeDur = .2f, time = 0, prevTime = 0, fade = 1;
};
inline const Clip* FindClip(const Skin& s, const std::string& n) { for (auto& c : s.clips) if (c.name == n) return &c; return nullptr; }
inline bool HasClip(const Skin& s, const std::string& n) { return FindClip(s, n) != nullptr; }
inline void PlayClip(AnimState& a, const std::string& n) {
  a.run = true; if (a.clip == n) return;
  a.prevClip = a.clip; a.prevTime = a.time; a.clip = n; a.time = 0; a.fade = (a.fadeDur > 0 && !a.prevClip.empty()) ? 0.f : 1.f;
}
inline void AdvanceAnim(AnimState& a, const Skin& s, float dt) {
  const Clip* c = FindClip(s, a.clip); if (!c) return;
  a.time += dt * a.speed;
  if (c->dur > 0) { if (a.loop) { a.time = std::fmod(a.time, c->dur); if (a.time < 0) a.time += c->dur; } else a.time = std::clamp(a.time, 0.f, c->dur); }
  if (a.fade < 1) { a.prevTime += dt * a.speed; a.fade = std::min(1.f, a.fade + dt / std::max(a.fadeDur, 1e-4f)); }
}
inline void SampleChannel(const Channel& c, float t, TRS& p) {
  size_t n = c.times.size(); if (!n || c.vals.size() < n) return;
  size_t i = 0; float f = 0;
  if (t >= c.times[n - 1]) i = n - 1;
  else if (t > c.times[0]) {
    i = std::upper_bound(c.times.begin(), c.times.end(), t) - c.times.begin() - 1;
    float d = c.times[i + 1] - c.times[i]; f = d > 1e-6f ? (t - c.times[i]) / d : 0;
  }
  if (c.interp == 1) f = 0;
  glm::vec4 a = c.vals[i], b = c.vals[std::min(i + 1, n - 1)];
  if (c.path == 1) p.r = glm::normalize(glm::slerp(glm::quat(a.w, a.x, a.y, a.z), glm::quat(b.w, b.x, b.y, b.z), f));
  else { glm::vec3 v = glm::mix(glm::vec3(a), glm::vec3(b), f); if (c.path == 0) p.t = v; else p.s = v; }
}
inline std::vector<TRS> SamplePose(const Skin& s, const std::string& clip, float t) {
  std::vector<TRS> p = s.rest;
  if (const Clip* c = FindClip(s, clip)) for (auto& ch : c->ch) if (ch.node >= 0 && ch.node < (int)p.size()) SampleChannel(ch, t, p[ch.node]);
  return p;
}
constexpr int MAX_BONES = 128;
inline void ComputeBones(const Skin& s, const AnimState& a, std::vector<glm::mat4>& out) {
  std::vector<TRS> p = SamplePose(s, a.clip, a.time);
  if (a.fade < 1 && !a.prevClip.empty()) {
    std::vector<TRS> q = SamplePose(s, a.prevClip, a.prevTime);
    for (size_t i = 0; i < p.size(); i++) {
      q[i].t = glm::mix(q[i].t, p[i].t, a.fade); q[i].s = glm::mix(q[i].s, p[i].s, a.fade); q[i].r = glm::slerp(q[i].r, p[i].r, a.fade);
    }
    p = q;
  }
  size_t N = p.size(); std::vector<glm::mat4> g(N); std::vector<char> done(N, 0);
  std::function<void(int)> gl = [&](int i) {
    if (done[i]) return; done[i] = 1;
    glm::mat4 l = glm::translate(glm::mat4(1), p[i].t) * glm::mat4_cast(p[i].r) * glm::scale(glm::mat4(1), p[i].s);
    if (s.parent[i] >= 0) { gl(s.parent[i]); g[i] = g[s.parent[i]] * l; } else g[i] = l;
  };
  out.resize(std::min<size_t>(s.joints.size(), MAX_BONES));
  for (size_t j = 0; j < out.size(); j++) { gl(s.joints[j]); out[j] = g[s.joints[j]] * s.ibm[j]; }
}
