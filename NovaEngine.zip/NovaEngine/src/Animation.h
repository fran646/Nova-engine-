#pragma once
#include <glm/glm.hpp>
#include <string>
#include <vector>
enum { P_POS = 0, P_ROT = 1, P_SCL = 2, P_COL = 3 };
struct Key { float t = 0; glm::vec4 v{0}; int ease = 1; };   // ease: 0 lineal, 1 suave, 2 escalón
struct Track { int prop = 0; std::vector<Key> keys; };
struct AnimClip { std::string name; float duration = 1; std::vector<Track> tracks; };
namespace Anim {
  const char* PropName(int p);
  Track& Ensure(AnimClip& c, int prop);
  void InsertKey(Track& tr, float t, glm::vec4 v, int ease);
  bool Sample(const AnimClip& c, float t, int prop, glm::vec4& out);
  bool Load(const std::string& path, AnimClip& out);
  bool Save(const AnimClip& c, const std::string& path);
}
