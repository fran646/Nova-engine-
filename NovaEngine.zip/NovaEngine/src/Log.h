#pragma once
#include <string>
#include <vector>
#include <cstdio>
inline std::vector<std::string>& LogBuf(){ static std::vector<std::string> b; return b; }
inline void Log(const std::string& s){ LogBuf().push_back(s); std::printf("%s\n", s.c_str()); }
