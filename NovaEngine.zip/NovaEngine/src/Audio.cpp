#define MINIAUDIO_IMPLEMENTATION
#include "miniaudio.h"
#include "Audio.h"
#include "Log.h"
#include <map>
#include <memory>
#include <vector>
static ma_engine g_engine; static bool g_ok = false;
static std::map<int, std::unique_ptr<ma_sound>> g_snd; static int g_next = 1;
namespace Audio {
bool Init() { g_ok = ma_engine_init(nullptr, &g_engine) == MA_SUCCESS; if (!g_ok) Log("Audio init failed"); return g_ok; }
void Shutdown() { StopAll(); if (g_ok) ma_engine_uninit(&g_engine); g_ok = false; }
int Play(const std::string& path, bool loop, float vol) {
  if (!g_ok) return -1;
  auto s = std::make_unique<ma_sound>();
  if (ma_sound_init_from_file(&g_engine, path.c_str(), MA_SOUND_FLAG_STREAM, nullptr, nullptr, s.get()) != MA_SUCCESS) { Log("Cannot play " + path); return -1; }
  ma_sound_set_looping(s.get(), loop ? MA_TRUE : MA_FALSE); ma_sound_set_volume(s.get(), vol); ma_sound_start(s.get());
  int id = g_next++; g_snd[id] = std::move(s); return id;
}
void Stop(int id) { auto it = g_snd.find(id); if (it == g_snd.end()) return; ma_sound_uninit(it->second.get()); g_snd.erase(it); }
void StopAll() { for (auto& kv : g_snd) ma_sound_uninit(kv.second.get()); g_snd.clear(); }
void Update() {
  std::vector<int> done;
  for (auto& kv : g_snd) if (!ma_sound_is_looping(kv.second.get()) && ma_sound_at_end(kv.second.get())) done.push_back(kv.first);
  for (int id : done) Stop(id);
}
}
