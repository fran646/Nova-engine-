#include "ScriptManager.h"
#include "Log.h"
#include <SDL.h>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <map>
namespace fs = std::filesystem;

#ifdef _WIN32
  #define NOVA_DLL_EXT ".dll"
#elif defined(__APPLE__)
  #define NOVA_DLL_EXT ".dylib"
#else
  #define NOVA_DLL_EXT ".so"
#endif

struct Loaded { void* handle = nullptr; NovaScript* api = nullptr; fs::file_time_type srcTime{}; std::string dll; };
static std::string g_dir, g_build;
static std::map<std::string, Loaded> g_loaded;

// Scripts integrados (siempre disponibles, también en Android)
static NovaScript kSpin{ "Spin", +[](NovaScriptCtx* c) { for (int k = 0; k < 3; k++) c->rot[k] += c->param[k] * c->dt; }, nullptr };
static NovaScript kMove{ "Move", +[](NovaScriptCtx* c) { for (int k = 0; k < 3; k++) c->pos[k] += c->param[k] * c->dt; }, nullptr };
static NovaScript kBob{ "Bob", +[](NovaScriptCtx* c) { c->pos[1] += std::cos(c->time * c->param[0]) * c->param[1] * c->param[0] * c->dt; }, nullptr };
static std::map<std::string, NovaScript*> g_builtin = { {"Spin", &kSpin}, {"Move", &kMove}, {"Bob", &kBob} };

static void PrintLog(const std::string& file) {
  std::ifstream f(file); std::string line; int n = 0;
  while (n++ < 20 && std::getline(f, line)) Log("  " + line);
}

static bool Compile(const std::string& src, const std::string& out) {
#ifdef _MSC_VER
  std::string cmd = "\"" NOVA_CXX "\" /nologo /LD /std:c++17 /EHsc /O2 /I\"" NOVA_INC "\" \"" + src +
                    "\" /Fe:\"" + out + "\" /Fo:\"" + out + ".obj\" > \"" + out + ".log\" 2>&1";
#else
  std::string cmd = "\"" NOVA_CXX "\" -shared -fPIC -std=c++17 -O2 -I\"" NOVA_INC "\" \"" + src +
                    "\" -o \"" + out + "\" > \"" + out + ".log\" 2>&1";
#endif
  int r = std::system(cmd.c_str());
  if (r != 0) { Log("Errores de compilación:"); PrintLog(out + ".log"); }
  std::error_code ec; fs::remove(out + ".log", ec);
  return r == 0;
}

// Sólo compila si no existe ya la versión de ESTE contenido (nombre con la fecha de modificación).
static bool Refresh(const fs::path& src) {
#ifdef __ANDROID__
  (void)src; return false;   // en Android no hay compilador: se usan los scripts integrados
#else
  std::string name = src.stem().string();
  auto srcT = fs::last_write_time(src);
  auto cur = g_loaded.find(name);
  if (cur != g_loaded.end() && cur->second.srcTime == srcT) return true;

  std::string tick = std::to_string(srcT.time_since_epoch().count());
  fs::path out = fs::path(g_build) / (name + "_" + tick + NOVA_DLL_EXT);
  std::error_code ec;
  if (!fs::exists(out, ec)) {
    Log("Compilando '" + name + "'...");
    if (!Compile(src.string(), out.string())) {
      Log("'" + name + "' no se recompiló; se mantiene la versión anterior");
      return false;
    }
  }
  void* h = SDL_LoadObject(out.string().c_str());
  if (!h) { Log("No se pudo cargar " + name + ": " + SDL_GetError()); return false; }
  auto getter = reinterpret_cast<NovaScript* (*)()>(SDL_LoadFunction(h, "nova_script"));
  NovaScript* api = getter ? getter() : nullptr;
  if (!api) { SDL_UnloadObject(h); Log("'" + name + "' no define NOVA_SCRIPT"); return false; }

  if (cur != g_loaded.end()) { SDL_UnloadObject(cur->second.handle); fs::remove(cur->second.dll, ec); }
  g_loaded[name] = Loaded{ h, api, srcT, out.string() };
  Log("Script listo: " + name);
  return true;
#endif
}

static void Scan() {
  std::error_code ec;
  for (auto& it : fs::directory_iterator(g_dir, ec))
    if (it.path().extension() == ".cpp") Refresh(it.path());
}

namespace ScriptManager {
void Init(const std::string& dir) {
  g_dir = dir; g_build = dir + "/build";
  std::error_code ec; fs::create_directories(g_build, ec);
  Scan();
}
void Poll() { Scan(); }

NovaScript* Get(const std::string& name) {
  auto it = g_loaded.find(name); if (it != g_loaded.end()) return it->second.api;
  auto b = g_builtin.find(name); return b != g_builtin.end() ? b->second : nullptr;
}

std::vector<std::string> Names() {
  std::vector<std::string> v;
  for (auto& kv : g_builtin) v.push_back(kv.first);
  for (auto& kv : g_loaded) if (!g_builtin.count(kv.first)) v.push_back(kv.first);
  return v;
}

bool CreateTemplate(const std::string& name) {
  std::error_code ec; fs::create_directories(g_dir, ec);
  fs::path p = fs::path(g_dir) / (name + ".cpp");
  if (fs::exists(p, ec)) return false;
  std::ofstream f(p);
  f << R"CODE(#include "ScriptAPI.h"

// Se ejecuta cada frame durante Play.
// c->pos, c->rot, c->scl, c->color, c->param, c->vel apuntan a los datos del objeto.
// c->dt = segundos del frame, c->time = tiempo total de Play.
NOVA_SCRIPT(")CODE" + name + R"CODE(", [](NovaScriptCtx* c) {
  c->rot[1] += 90.0f * c->dt;   // ejemplo: girar sobre el eje Y
})CODE";
  return true;
}

void Shutdown() {
  for (auto& kv : g_loaded) { SDL_UnloadObject(kv.second.handle); }
  g_loaded.clear();
}
}
