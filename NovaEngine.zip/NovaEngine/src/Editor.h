#pragma once
#include "imgui.h"
#include "ImGuizmo.h"
#include "Gfx.h"
#include "Scene.h"
#include "Assets.h"
#include "Renderer.h"
#include <string>

struct Editor {
  Scene scene, backup; Assets assets; Renderer rend; Fbo sceneFbo, gameFbo;
  int sel = -1, del = -1, tool = 1; bool playing = false, wantQuit = false, pan = false, local = false;
  float time = 0, physAcc = 0, reloadTimer = 0;
  float yaw = 35, pitch = 25, dist = 9; glm::vec3 target{0, .5f, 0};
  char importPath[512] = { 0 }, newScript[64] = { 0 }, newClip[64] = { 0 };
  std::string scenePath = "Main.scene", editClip; float editTime = 0; int easeNew = 1;

  void Init(const std::string& assetDir);
  void Frame(float dt);
  void Import(const std::string& p);

  void Menu(); void Dock(); void Hierarchy(); void Tree(int id); void Inspector(); void Project();
  void Console(); void AnimPanel(); void SceneView(); void GameView();
  void Create(const std::string& kind, int parent = -1); void CreateMenu();
  void Duplicate(int id); void NewScene(); void TogglePlay(); void SpawnAsset(const std::string& n, glm::vec3 at);
  void ApplyClip(Entity& e, const AnimClip& c, float t);
  void RunScripts(float dt); void RunAnimators(float dt); void RunPhysics(float dt);
  bool CamMatrices(Entity& c, float aspect, glm::mat4& v, glm::mat4& p);
};
