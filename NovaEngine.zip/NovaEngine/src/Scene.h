#pragma once
#include "imgui.h"
#include "ImGuizmo.h"
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <algorithm>

struct Entity {
  int id = 0, parent = -1; std::string name = "Entity"; bool active = true;
  glm::vec3 pos{0}, rot{0}, scl{1};
  // Mesh renderer
  bool hasMesh = false; std::string mesh = "Cube", tex; glm::vec4 color{1};
  std::vector<std::string> subTex;                   // textura por submalla (vacío = la del modelo)
  // Sprite (2D)
  bool hasSprite = false; std::string sprite; glm::vec4 sprColor{1};
  // Camera / light
  bool hasCamera = false, ortho = false; float fov = 60, orthoSize = 5;
  bool hasLight = false; glm::vec3 lightColor{1}; float intensity = 1;
  // Audio
  bool hasAudio = false; std::string clip; bool loop = true, playOnStart = true; float volume = 1;
  // Scripts
  std::string script; glm::vec3 sparam{0, 45, 0};
  // Collider
  bool hasCollider = false; int colKind = 0; glm::vec3 colSize{1}; float colRadius = .5f;  // colKind 0 caja, 1 esfera
  // Rigidbody
  bool hasBody = false, bodyStatic = false, body2D = false;
  float mass = 1, bounce = .2f, friction = .5f, gravityScale = 1;
  // Animator
  bool hasAnim = false; std::string animClip; float animSpeed = 1; bool animLoop = true, animAutoPlay = true;
  // Runtime (no se guarda)
  glm::vec3 vel{0}; bool grounded = false; bool scriptStarted = false;
  float animTime = 0; bool animPlaying = false;
};

struct Scene {
  std::vector<Entity> e; int next = 1;
  Entity& Add(const std::string& n, int parent = -1) { Entity x; x.id = next++; x.name = n; x.parent = parent; e.push_back(x); return e.back(); }
  Entity* Find(int id) { for (auto& x : e) if (x.id == id) return &x; return nullptr; }
  static glm::mat4 Local(const Entity& x) {
    float p[3] = {x.pos.x,x.pos.y,x.pos.z}, r[3] = {x.rot.x,x.rot.y,x.rot.z}, s[3] = {x.scl.x,x.scl.y,x.scl.z}, m[16];
    ImGuizmo::RecomposeMatrixFromComponents(p, r, s, m); return glm::make_mat4(m);
  }
  glm::mat4 World(const Entity& x) {
    glm::mat4 m = Local(x); const Entity* c = &x; int guard = 0;
    while (c->parent >= 0 && guard++ < 64) { c = Find(c->parent); if (!c) break; m = Local(*c) * m; }
    return m;
  }
  void SetLocalFromMatrix(Entity& x, const glm::mat4& l) {
    float t[3], r[3], s[3]; ImGuizmo::DecomposeMatrixToComponents(glm::value_ptr(l), t, r, s);
    x.pos = glm::make_vec3(t); x.rot = glm::make_vec3(r); x.scl = glm::make_vec3(s);
  }
  void SetParent(int id, int np) {
    if (id == np) return; Entity* x = Find(id); if (!x) return;
    for (int c = np; c >= 0;) { if (c == id) return; Entity* p = Find(c); if (!p) break; c = p->parent; }
    glm::mat4 w = World(*x), pw(1);
    if (np >= 0) { Entity* p = Find(np); if (!p) return; pw = World(*p); }
    x->parent = np; SetLocalFromMatrix(*x, glm::inverse(pw) * w);
  }
  void Remove(int id) {
    std::vector<int> kill{ id };
    for (size_t k = 0; k < kill.size(); k++) for (auto& x : e) if (x.parent == kill[k]) kill.push_back(x.id);
    e.erase(std::remove_if(e.begin(), e.end(), [&](const Entity& x) { return std::find(kill.begin(), kill.end(), x.id) != kill.end(); }), e.end());
  }
};

inline void SaveScene(Scene& s, const std::string& path) {
  std::ofstream o(path); o << std::setprecision(9) << "NOVA2 " << s.next << "\n";
  auto v3 = [&](const glm::vec3& v) { o << v.x << ' ' << v.y << ' ' << v.z << ' '; };
  auto v4 = [&](const glm::vec4& v) { o << v.x << ' ' << v.y << ' ' << v.z << ' ' << v.w << ' '; };
  for (auto& x : s.e) {
    o << x.id << ' ' << x.parent << ' ' << std::quoted(x.name) << ' ' << x.active << ' '; v3(x.pos); v3(x.rot); v3(x.scl);
    o << x.hasMesh << ' ' << std::quoted(x.mesh) << ' ' << std::quoted(x.tex) << ' '; v4(x.color);
    o << x.subTex.size() << ' '; for (auto& t : x.subTex) o << std::quoted(t) << ' ';
    o << x.hasSprite << ' ' << std::quoted(x.sprite) << ' '; v4(x.sprColor);
    o << x.hasCamera << ' ' << x.ortho << ' ' << x.fov << ' ' << x.orthoSize << ' ' << x.hasLight << ' '; v3(x.lightColor);
    o << x.intensity << ' ';
    o << x.hasAudio << ' ' << std::quoted(x.clip) << ' ' << x.loop << ' ' << x.playOnStart << ' ' << x.volume << ' ';
    o << std::quoted(x.script) << ' '; v3(x.sparam);
    o << x.hasCollider << ' ' << x.colKind << ' '; v3(x.colSize); o << x.colRadius << ' ';
    o << x.hasBody << ' ' << x.bodyStatic << ' ' << x.body2D << ' '
      << x.mass << ' ' << x.bounce << ' ' << x.friction << ' ' << x.gravityScale << ' ';
    o << x.hasAnim << ' ' << std::quoted(x.animClip) << ' ' << x.animSpeed << ' ' << x.animLoop << ' ' << x.animAutoPlay << "\n";
  }
}

inline bool LoadScene(Scene& s, const std::string& path) {
  std::ifstream i(path); if (!i) return false;
  std::string magic; int next = 1; i >> magic >> next; if (magic != "NOVA2") return false;
  Scene ns; ns.next = next;
  auto B = [&](bool& b) { int t = 0; i >> t; b = t != 0; };
  auto v3 = [&](glm::vec3& v) { i >> v.x >> v.y >> v.z; };
  auto v4 = [&](glm::vec4& v) { i >> v.x >> v.y >> v.z >> v.w; };
  while (true) {
    Entity x;
    if (!(i >> x.id >> x.parent >> std::quoted(x.name))) break;
    B(x.active); v3(x.pos); v3(x.rot); v3(x.scl);
    B(x.hasMesh); i >> std::quoted(x.mesh) >> std::quoted(x.tex); v4(x.color);
    size_t nsub = 0; i >> nsub; x.subTex.resize(nsub); for (auto& t : x.subTex) i >> std::quoted(t);
    B(x.hasSprite); i >> std::quoted(x.sprite); v4(x.sprColor);
    B(x.hasCamera); B(x.ortho); i >> x.fov >> x.orthoSize; B(x.hasLight); v3(x.lightColor); i >> x.intensity;
    B(x.hasAudio); i >> std::quoted(x.clip); B(x.loop); B(x.playOnStart); i >> x.volume;
    i >> std::quoted(x.script); v3(x.sparam);
    B(x.hasCollider); i >> x.colKind; v3(x.colSize); i >> x.colRadius;
    B(x.hasBody); B(x.bodyStatic); B(x.body2D); i >> x.mass >> x.bounce >> x.friction >> x.gravityScale;
    B(x.hasAnim); i >> std::quoted(x.animClip) >> x.animSpeed; B(x.animLoop); B(x.animAutoPlay);
    ns.e.push_back(x);
  }
  s = ns; return true;
}
