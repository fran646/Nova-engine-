#pragma once
#include "Scene.h"
namespace Physics {
  constexpr float kStep = 1.f / 60.f;   // paso fijo
  // Gravedad, integración, colisiones de caja/esfera (AABB en espacio mundo) y rebote con fricción.
  void Step(Scene& s, float dt);
}
