#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define TINYGLTF_IMPLEMENTATION
#define TINYGLTF_NO_STB_IMAGE_WRITE
#include "tiny_gltf.h"
#include "Assets.h"
#include "Log.h"
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <functional>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/quaternion.hpp>
namespace fs = std::filesystem;

std::string Assets::Kind(const std::string& f) {
  std::string e = fs::path(f).extension().string();
  std::transform(e.begin(), e.end(), e.begin(), ::tolower);
  if (e == ".png" || e == ".jpg" || e == ".jpeg" || e == ".bmp" || e == ".tga") return "texture";
  if (e == ".glb" || e == ".gltf") return "model";
  if (e == ".wav" || e == ".mp3" || e == ".ogg" || e == ".flac") return "audio";
  if (e == ".anim") return "anim";
  if (e == ".scene") return "scene";
  if (e == ".cpp") return "script";
  return "other";
}

static void AddPrim(Assets& a, const std::string& n, std::shared_ptr<Mesh> m) {
  Model md; md.subs.push_back({ m, "" }); md.radius = m->radius; a.models[n] = md;
}

void Assets::Init(const std::string& d) {
  dir = d; std::error_code ec; fs::create_directories(dir, ec);
  unsigned char px[4] = { 255, 255, 255, 255 }; white = MakeTexture(px, 1, 1);
  AddPrim(*this, "Cube", MakeCube()); AddPrim(*this, "Sphere", MakeSphere());
  AddPrim(*this, "Plane", MakePlane()); AddPrim(*this, "Quad", MakeQuad());
  Scan();
}

void Assets::Scan() {
  files.clear(); std::error_code ec;
  for (auto& it : fs::directory_iterator(dir, ec)) {
    if (!it.is_regular_file()) continue;
    std::string n = it.path().filename().string(); files.push_back(n);
    std::string k = Kind(n);
    bool known = (k == "texture" && tex.count(n)) || (k == "model" && models.count(n)) ||
                 (k == "audio" && audio.count(n)) || (k == "anim" && anims.count(n));
    if (!known) Load(it.path().string());
  }
  std::sort(files.begin(), files.end());
}

bool Assets::Import(const std::string& src) {
  std::error_code ec; fs::path p(src);
  if (!fs::exists(p, ec)) { Log("Archivo no encontrado: " + src); return false; }
  if (Kind(p.filename().string()) == "other") { Log("Tipo no soportado: " + p.filename().string()); return false; }
  fs::path dest = fs::path(dir) / p.filename();
  if (fs::absolute(p, ec) != fs::absolute(dest, ec)) fs::copy_file(p, dest, fs::copy_options::overwrite_existing, ec);
  bool ok = Load(dest.string()); Scan(); return ok;
}

bool Assets::Load(const std::string& path) {
  std::string name = fs::path(path).filename().string(), k = Kind(name);
  if (k == "texture") {
    int w, h, c; unsigned char* d = stbi_load(path.c_str(), &w, &h, &c, 4);
    if (!d) { Log("No se pudo leer la imagen " + name); return false; }
    tex[name] = MakeTexture(d, w, h); stbi_image_free(d); Log("Textura importada: " + name); return true;
  }
  if (k == "model") return LoadModel(path, name);
  if (k == "audio") { audio[name] = path; Log("Audio importado: " + name); return true; }
  if (k == "anim") {
    AnimClip c; if (!Anim::Load(path, c)) { Log("Clip de animación inválido: " + name); return false; }
    c.name = name; anims[name] = c; Log("Animación importada: " + name); return true;
  }
  return false;
}

bool Assets::LoadModel(const std::string& path, const std::string& name) {
  tinygltf::TinyGLTF loader; tinygltf::Model m; std::string err, warn;
  bool binary = fs::path(path).extension() == ".glb";
  bool ok = binary ? loader.LoadBinaryFromFile(&m, &err, &warn, path) : loader.LoadASCIIFromFile(&m, &err, &warn, path);
  if (!ok) { Log("Error de modelo (" + name + "): " + err); return false; }

  Model md;
  std::map<int, std::string> texOfImage;   // imagen glTF -> nombre interno de textura
  bool warned = false;

  auto imageTex = [&](int texIdx) -> std::string {
    if (texIdx < 0 || texIdx >= (int)m.textures.size()) return "";
    int src = m.textures[texIdx].source;
    if (src < 0 || src >= (int)m.images.size()) return "";
    auto f = texOfImage.find(src); if (f != texOfImage.end()) return f->second;
    if ((int)texOfImage.size() >= kMaxTextures) {
      if (!warned) { Log("'" + name + "' supera " + std::to_string(kMaxTextures) + " texturas; el resto usa blanco"); warned = true; }
      return "";
    }
    auto& img = m.images[src];
    if (img.image.empty() || img.bits != 8 || (img.component != 3 && img.component != 4)) return "";
    size_t n = (size_t)img.width * img.height;
    std::vector<unsigned char> rgba(n * 4);
    if (img.component == 4) std::memcpy(rgba.data(), img.image.data(), n * 4);
    else for (size_t p = 0; p < n; p++) {
      rgba[p * 4] = img.image[p * 3]; rgba[p * 4 + 1] = img.image[p * 3 + 1];
      rgba[p * 4 + 2] = img.image[p * 3 + 2]; rgba[p * 4 + 3] = 255;
    }
    std::string tn = name + "#" + std::to_string(src);
    tex[tn] = MakeTexture(rgba.data(), img.width, img.height);
    texOfImage[src] = tn;
    return tn;
  };

  auto acc = [&](int a, size_t& cnt, size_t& stride) -> const unsigned char* {
    auto& A = m.accessors[a]; auto& bv = m.bufferViews[A.bufferView];
    cnt = A.count; stride = (size_t)A.ByteStride(bv);
    return m.buffers[bv.buffer].data.data() + bv.byteOffset + A.byteOffset;
  };

  std::function<void(int, glm::mat4)> visit = [&](int ni, glm::mat4 parent) {
    auto& n = m.nodes[ni]; glm::mat4 local(1);
    if (n.matrix.size() == 16) { for (int k = 0; k < 16; k++) ((float*)&local)[k] = (float)n.matrix[k]; }
    else {
      glm::vec3 t(0), s(1); glm::quat q(1, 0, 0, 0);
      if (n.translation.size() == 3) t = glm::vec3((float)n.translation[0], (float)n.translation[1], (float)n.translation[2]);
      if (n.rotation.size() == 4) q = glm::quat((float)n.rotation[3], (float)n.rotation[0], (float)n.rotation[1], (float)n.rotation[2]);
      if (n.scale.size() == 3) s = glm::vec3((float)n.scale[0], (float)n.scale[1], (float)n.scale[2]);
      local = glm::translate(glm::mat4(1), t) * glm::mat4_cast(q) * glm::scale(glm::mat4(1), s);
    }
    glm::mat4 w = parent * local; glm::mat3 nm = glm::mat3(glm::transpose(glm::inverse(w)));

    if (n.mesh >= 0) for (auto& p : m.meshes[n.mesh].primitives) {
      if (p.mode != 4 && p.mode != -1) continue;                      // sólo triángulos
      auto pa = p.attributes.find("POSITION"); if (pa == p.attributes.end()) continue;
      size_t cnt, st; const unsigned char* pp = acc(pa->second, cnt, st);
      size_t ncnt = 0, nst = 0, ucnt = 0, ust = 0; const unsigned char* np = nullptr; const unsigned char* up = nullptr;
      auto na = p.attributes.find("NORMAL"); if (na != p.attributes.end()) np = acc(na->second, ncnt, nst);
      auto ua = p.attributes.find("TEXCOORD_0"); if (ua != p.attributes.end()) up = acc(ua->second, ucnt, ust);

      std::vector<Vertex> V; std::vector<uint32_t> I; V.reserve(cnt);
      for (size_t k = 0; k < cnt; k++) {
        glm::vec3 pos, nor(0, 1, 0); glm::vec2 uv(0); std::memcpy(&pos, pp + k * st, 12);
        if (np) std::memcpy(&nor, np + k * nst, 12);
        if (up) std::memcpy(&uv, up + k * ust, 8);
        V.push_back({ glm::vec3(w * glm::vec4(pos, 1)), glm::normalize(nm * nor), uv });
      }
      if (p.indices >= 0) {
        size_t ic, is; const unsigned char* ip = acc(p.indices, ic, is); int ct = m.accessors[p.indices].componentType;
        for (size_t k = 0; k < ic; k++) {
          uint32_t v = 0; const unsigned char* q = ip + k * is;
          if (ct == 5121) v = *q;
          else if (ct == 5123) { uint16_t t; std::memcpy(&t, q, 2); v = t; }
          else std::memcpy(&v, q, 4);
          I.push_back(v);
        }
      } else for (uint32_t k = 0; k < cnt; k++) I.push_back(k);

      auto mesh = std::make_shared<Mesh>(); mesh->Create(V, I);
      std::string t = p.material >= 0 ? imageTex(m.materials[p.material].pbrMetallicRoughness.baseColorTexture.index) : "";
      md.subs.push_back({ mesh, t });
      md.radius = std::max(md.radius, mesh->radius);
    }
    for (int c : n.children) visit(c, w);
  };

  if (!m.scenes.empty()) { int s = m.defaultScene >= 0 ? m.defaultScene : 0; for (int r : m.scenes[s].nodes) visit(r, glm::mat4(1)); }
  else for (size_t k = 0; k < m.nodes.size(); k++) visit((int)k, glm::mat4(1));

  if (md.subs.empty()) { Log("El modelo no tiene triángulos: " + name); return false; }
  models[name] = md;
  Log("Modelo importado: " + name + " (" + std::to_string(md.subs.size()) + " submallas, " +
      std::to_string(texOfImage.size()) + " texturas)");
  return true;
}
