#pragma once
#include "ScriptAPI.h"
#include <string>
#include <vector>
namespace ScriptManager {
  void Init(const std::string& scriptsDir);
  void Poll();                                   // llamar ~cada 0.5 s: recompila sólo lo editado
  NovaScript* Get(const std::string& name);
  std::vector<std::string> Names();
  bool CreateTemplate(const std::string& name);
  void Shutdown();
}
