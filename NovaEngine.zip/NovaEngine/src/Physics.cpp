#include "Physics.h"
#include <glm/gtc/matrix_transform.hpp>
#include <algorithm>
#include <cmath>

namespace Physics {
struct Col { glm::vec3 c, h; bool sphere = false; float r = 0; bool flat = false; };
struct Hit { bool hit = false; glm::vec3 n{0, 1, 0}; float depth = 0; };

static Hit BoxBox(const Col& a, const Col& b) {          // n apunta de a hacia b
  glm::vec3 d = b.c - a.c, ov = a.h + b.h - glm::abs(d);
  if (ov.x <= 0 || ov.y <= 0 || ov.z <= 0) return {};
  int ax = 0; if (ov.y < ov[ax]) ax = 1; if (ov.z < ov[ax]) ax = 2;
  Hit h; h.hit = true; h.depth = ov[ax]; h.n = glm::vec3(0); h.n[ax] = d[ax] < 0 ? -1.f : 1.f; return h;
}
static Hit SphereSphere(const Col& a, const Col& b) {
  glm::vec3 d = b.c - a.c; if (a.flat || b.flat) d.z = 0;
  float dist = glm::length(d), rs = a.r + b.r;
  if (dist >= rs) return {};
  Hit h; h.hit = true; h.depth = rs - dist; h.n = dist > 1e-6f ? d / dist : glm::vec3(0, 1, 0); return h;
}
static Hit SphereBox(const Col& s, const Col& b) {       // n apunta de la esfera hacia la caja
  glm::vec3 q = glm::clamp(s.c, b.c - b.h, b.c + b.h), d = q - s.c;
  float dist = glm::length(d);
  if (dist > 1e-6f) {
    if (dist >= s.r) return {};
    Hit h; h.hit = true; h.depth = s.r - dist; h.n = d / dist; return h;
  }
  Col sb; sb.c = s.c; sb.h = glm::vec3(s.r); sb.flat = s.flat;   // centro dentro de la caja
  return BoxBox(sb, b);
}
static Hit Test(const Col& a, const Col& b) {
  if (!a.sphere && !b.sphere) return BoxBox(a, b);
  if (a.sphere && b.sphere) return SphereSphere(a, b);
  if (a.sphere) return SphereBox(a, b);
  Hit h = SphereBox(b, a); h.n = -h.n; return h;
}

static Col Bounds(Scene& s, Entity& e) {
  glm::mat4 W = s.World(e);
  glm::vec3 sc(glm::length(glm::vec3(W[0])), glm::length(glm::vec3(W[1])), glm::length(glm::vec3(W[2])));
  Col c; c.c = glm::vec3(W[3]); c.sphere = e.colKind == 1; c.flat = e.body2D;
  c.r = e.colRadius * std::max(sc.x, std::max(sc.y, sc.z));
  c.h = e.colSize * sc * .5f; if (c.flat) c.h.z = 1e4f;
  return c;
}

// Mueve una entidad en espacio mundo (respetando la jerarquía).
static void Move(Scene& s, Entity& e, glm::vec3 d) {
  if (glm::dot(d, d) == 0.f) return;
  Entity* p = e.parent >= 0 ? s.Find(e.parent) : nullptr;
  if (!p) { e.pos += d; return; }
  glm::mat4 w = glm::translate(glm::mat4(1), d) * s.World(e);
  glm::mat4 pw = s.World(*p);
  s.SetLocalFromMatrix(e, glm::inverse(pw) * w);
}

static void Resolve(Scene& s, Entity& A, Entity& B, bool dA, bool dB, const Hit& h) {
  float ia = dA ? 1.f / std::max(A.mass, 1e-4f) : 0.f;
  float ib = dB ? 1.f / std::max(B.mass, 1e-4f) : 0.f;
  float inv = ia + ib; if (inv <= 0.f) return;
  glm::vec3 n = h.n;
  Move(s, A, -n * (h.depth * ia / inv));           // separar posiciones
  Move(s, B,  n * (h.depth * ib / inv));
  if (dA && n.y < -.5f) A.grounded = true;
  if (dB && n.y >  .5f) B.grounded = true;

  glm::vec3 rv = B.vel - A.vel; float vn = glm::dot(rv, n);
  if (vn >= 0.f) return;                            // ya se separan
  float e = std::min(A.bounce, B.bounce);
  float j = -(1.f + e) * vn / inv;
  A.vel -= n * (j * ia); B.vel += n * (j * ib);

  rv = B.vel - A.vel;                                // fricción de Coulomb
  glm::vec3 t = rv - n * glm::dot(rv, n); float tl = glm::length(t);
  if (tl > 1e-5f) {
    t /= tl;
    float f = -glm::dot(rv, t) / inv;
    float maxF = j * std::sqrt(A.friction * B.friction);
    f = std::max(-maxF, std::min(maxF, f));
    A.vel -= t * (f * ia); B.vel += t * (f * ib);
  }
}

void Step(Scene& s, float dt) {
  for (auto& e : s.e) if (e.active && e.hasBody && !e.bodyStatic) {
    e.grounded = false;
    e.vel.y -= 9.81f * e.gravityScale * dt;
    if (e.body2D) e.vel.z = 0.f;
    Move(s, e, e.vel * dt);
  }
  for (int it = 0; it < 4; it++)
    for (size_t i = 0; i < s.e.size(); i++)
      for (size_t j = i + 1; j < s.e.size(); j++) {
        Entity& A = s.e[i]; Entity& B = s.e[j];
        if (!A.active || !B.active || !A.hasCollider || !B.hasCollider) continue;
        bool dA = A.hasBody && !A.bodyStatic, dB = B.hasBody && !B.bodyStatic;
        if (!dA && !dB) continue;
        Hit h = Test(Bounds(s, A), Bounds(s, B));
        if (h.hit) Resolve(s, A, B, dA, dB, h);
      }
}
}
