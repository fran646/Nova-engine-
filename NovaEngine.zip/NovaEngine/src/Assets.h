#pragma once
#include "Gfx.h"
#include "Animation.h"
#include <map>
#include <string>
#include <vector>
#include <memory>

constexpr int kMaxTextures = 100;   // máximo de texturas por modelo

struct SubMesh { std::shared_ptr<Mesh> mesh; std::string tex; };   // una submalla = una primitiva glTF + su textura
struct Model { std::vector<SubMesh> subs; float radius = 1; };

struct Assets {
  std::string dir;
  std::map<std::string, Texture> tex;
  std::map<std::string, Model> models;       // primitivas (Cube, Sphere, Plane, Quad) + modelos importados
  std::map<std::string, AnimClip> anims;
  std::map<std::string, std::string> audio;  // nombre -> ruta
  std::vector<std::string> files;
  Texture white;

  void Init(const std::string& assetsDir);
  void Scan();
  bool Import(const std::string& src);
  bool Load(const std::string& path);
  bool LoadModel(const std::string& path, const std::string& name);
  static std::string Kind(const std::string& filename);

  Model* GetModel(const std::string& n) { auto it = models.find(n); return it == models.end() ? nullptr : &it->second; }
  Mesh* Prim(const std::string& n) { Model* m = GetModel(n); return (m && !m->subs.empty()) ? m->subs[0].mesh.get() : nullptr; }
  Texture& GetTex(const std::string& n) { auto t = tex.find(n); return t == tex.end() ? white : t->second; }
};
