#include "Editor.h"
#include "Audio.h"
#include "Physics.h"
#include "Animation.h"
#include "ScriptManager.h"
#include "Log.h"
#include <SDL.h>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

static bool Combo(const char* label, std::string& cur, const std::vector<std::string>& items, bool allowNone) {
  bool ch = false;
  if (ImGui::BeginCombo(label, cur.empty() ? "(ninguno)" : cur.c_str())) {
    if (allowNone && ImGui::Selectable("(ninguno)", cur.empty())) { cur.clear(); ch = true; }
    for (auto& s : items) if (ImGui::Selectable(s.c_str(), s == cur)) { cur = s; ch = true; }
    ImGui::EndCombo();
  }
  return ch;
}

void Editor::Init(const std::string& dir) {
  assets.Init(dir); rend.Init();
  ScriptManager::Init(std::filesystem::path(dir).parent_path().string() + "/Scripts");
  if (std::filesystem::exists(dir + "/" + scenePath) && LoadScene(scene, dir + "/" + scenePath)) Log("Cargada " + scenePath);
  else NewScene();
}
void Editor::Import(const std::string& p) { assets.Import(p); }

void Editor::NewScene() {
  scene = Scene(); sel = -1;
  Create("Camera"); Entity* c = scene.Find(sel); c->name = "Main Camera"; c->pos = { 0, 2, 7 }; c->rot = { -14, 0, 0 };
  Create("Light"); Entity* l = scene.Find(sel); l->name = "Directional Light"; l->rot = { -50, -30, 0 };
  Create("Cube"); sel = -1;
}

void Editor::Create(const std::string& k, int parent) {
  Entity& x = scene.Add(k, parent);
  if (k == "Cube" || k == "Sphere" || k == "Plane") { x.hasMesh = true; x.mesh = k; }
  else if (k == "Sprite") x.hasSprite = true;
  else if (k == "Camera") x.hasCamera = true;
  else if (k == "Light") { x.hasLight = true; x.rot = { -50, -30, 0 }; }
  sel = x.id;
}
void Editor::CreateMenu() {
  for (const char* k : { "Empty", "Cube", "Sphere", "Plane", "Sprite", "Camera", "Light" }) if (ImGui::MenuItem(k)) Create(k);
}
void Editor::Duplicate(int id) {
  Entity* x = scene.Find(id); if (!x) return;
  Entity c = *x; c.id = scene.next++; c.name += " (copia)"; scene.e.push_back(c); sel = c.id;
}
void Editor::SpawnAsset(const std::string& n, glm::vec3 at) {
  std::string k = Assets::Kind(n);
  Create("Empty"); Entity* x = scene.Find(sel); x->name = n; x->pos = at;
  if (k == "texture") { x->hasSprite = true; x->sprite = n; }
  else if (k == "model") { x->hasMesh = true; x->mesh = n; }
  else if (k == "audio") { x->hasAudio = true; x->clip = n; }
  else if (k == "anim")  { x->hasAnim = true; x->animClip = n; }
}

void Editor::TogglePlay() {
  if (!playing) {
    backup = scene; playing = true; time = 0; physAcc = 0;
    for (auto& x : scene.e) {
      x.animTime = 0; x.animPlaying = x.hasAnim && x.animAutoPlay; x.scriptStarted = false; x.grounded = false;
      if (x.active && x.hasAudio && x.playOnStart && !x.clip.empty() && assets.audio.count(x.clip))
        Audio::Play(assets.audio[x.clip], x.loop, x.volume);
    }
  } else { Audio::StopAll(); scene = backup; playing = false; }
}

bool Editor::CamMatrices(Entity& c, float aspect, glm::mat4& v, glm::mat4& p) {
  v = glm::inverse(scene.World(c));
  if (c.ortho) { float h = c.orthoSize; p = glm::ortho(-h * aspect, h * aspect, -h, h, -100.f, 100.f); }
  else p = glm::perspective(glm::radians(c.fov), aspect, .05f, 500.f);
  return true;
}

void Editor::ApplyClip(Entity& e, const AnimClip& c, float t) {
  glm::vec4 v;
  if (Anim::Sample(c, t, P_POS, v)) e.pos = glm::vec3(v);
  if (Anim::Sample(c, t, P_ROT, v)) e.rot = glm::vec3(v);
  if (Anim::Sample(c, t, P_SCL, v)) e.scl = glm::vec3(v);
  if (Anim::Sample(c, t, P_COL, v)) e.color = v;
}

void Editor::RunScripts(float dt) {
  for (auto& x : scene.e) {
    if (!x.active || x.script.empty()) continue;
    NovaScript* s = ScriptManager::Get(x.script); if (!s) continue;
    NovaScriptCtx c{};
    c.pos = &x.pos.x; c.rot = &x.rot.x; c.scl = &x.scl.x; c.color = &x.color.x;
    c.param = &x.sparam.x; c.vel = &x.vel.x;
    c.dt = dt; c.time = time; c.entityId = x.id; c.grounded = x.grounded ? 1 : 0;
    if (!x.scriptStarted) { x.scriptStarted = true; if (s->start) s->start(&c); }
    if (s->update) s->update(&c);
  }
}

void Editor::RunAnimators(float dt) {
  for (auto& e : scene.e) {
    if (!e.active || !e.hasAnim || !e.animPlaying) continue;
    auto it = assets.anims.find(e.animClip); if (it == assets.anims.end()) continue;
    const AnimClip& c = it->second;
    e.animTime += dt * e.animSpeed;
    if (c.duration > 0) {
      if (e.animLoop) { e.animTime = std::fmod(e.animTime, c.duration); if (e.animTime < 0) e.animTime += c.duration; }
      else if (e.animTime >= c.duration) { e.animTime = c.duration; e.animPlaying = false; }
    }
    ApplyClip(e, c, e.animTime);
  }
}

void Editor::RunPhysics(float dt) {
  physAcc += dt; int steps = 0;
  while (physAcc >= Physics::kStep && steps < 5) { Physics::Step(scene, Physics::kStep); physAcc -= Physics::kStep; steps++; }
  if (steps == 5) physAcc = 0;
}

void Editor::Frame(float dt) {
  Audio::Update();
  reloadTimer -= dt;
  if (reloadTimer <= 0) { reloadTimer = .5f; ScriptManager::Poll(); }   // recompila sólo scripts editados
  if (playing) { time += dt; RunScripts(dt); RunAnimators(dt); RunPhysics(dt); }
  Menu(); Dock(); Hierarchy(); Inspector(); Project(); Console(); AnimPanel(); SceneView(); GameView();
}

void Editor::Menu() {
  if (ImGui::BeginMainMenuBar()) {
    if (ImGui::BeginMenu("Archivo")) {
      if (ImGui::MenuItem("Nueva escena")) NewScene();
      if (ImGui::MenuItem("Guardar escena")) { SaveScene(scene, assets.dir + "/" + scenePath); assets.Scan(); Log("Guardada " + scenePath); }
      if (ImGui::MenuItem("Cargar escena")) { if (LoadScene(scene, assets.dir + "/" + scenePath)) { sel = -1; Log("Cargada " + scenePath); } }
      ImGui::Separator(); if (ImGui::MenuItem("Salir")) wantQuit = true;
      ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("GameObject")) { CreateMenu(); ImGui::EndMenu(); }
    ImGui::SameLine(ImGui::GetWindowWidth() * .5f - 30);
    if (ImGui::Button(playing ? "  Detener  " : "  Jugar  ")) TogglePlay();
    ImGui::EndMainMenuBar();
  }
}

void Editor::Dock() {
  ImGuiViewport* vp = ImGui::GetMainViewport();
  ImGui::SetNextWindowPos(vp->WorkPos); ImGui::SetNextWindowSize(vp->WorkSize);
  ImGuiWindowFlags f = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
                       ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNavFocus |
                       ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoBackground;
  ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
  ImGui::Begin("##dockhost", nullptr, f); ImGui::PopStyleVar();
  ImGuiID id = ImGui::GetID("MainDock");
  if (!ImGui::DockBuilderGetNode(id)) {
    ImGui::DockBuilderRemoveNode(id); ImGui::DockBuilderAddNode(id, ImGuiDockNodeFlags_DockSpace);
    ImGui::DockBuilderSetNodeSize(id, vp->WorkSize);
    ImGuiID center = id, left, right, bottom;
    left = ImGui::DockBuilderSplitNode(center, ImGuiDir_Left, .2f, nullptr, &center);
    right = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, .26f, nullptr, &center);
    bottom = ImGui::DockBuilderSplitNode(center, ImGuiDir_Down, .28f, nullptr, &center);
    ImGui::DockBuilderDockWindow("Hierarchy", left); ImGui::DockBuilderDockWindow("Inspector", right);
    ImGui::DockBuilderDockWindow("Project", bottom); ImGui::DockBuilderDockWindow("Console", bottom);
    ImGui::DockBuilderDockWindow("Animation", bottom);
    ImGui::DockBuilderDockWindow("Scene", center); ImGui::DockBuilderDockWindow("Game", center);
    ImGui::DockBuilderFinish(id);
  }
  ImGui::DockSpace(id, ImVec2(0, 0));
  ImGui::End();
}

void Editor::Tree(int id) {
  Entity* x = scene.Find(id); if (!x) return;
  std::vector<int> kids; for (auto& c : scene.e) if (c.parent == id) kids.push_back(c.id);
  ImGuiTreeNodeFlags f = ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_SpanAvailWidth | ImGuiTreeNodeFlags_DefaultOpen;
  if (kids.empty()) f |= ImGuiTreeNodeFlags_Leaf;
  if (sel == id) f |= ImGuiTreeNodeFlags_Selected;
  bool open = ImGui::TreeNodeEx((void*)(intptr_t)id, f, "%s", x->name.c_str());
  if (ImGui::IsItemClicked() && !ImGui::IsItemToggledOpen()) sel = id;
  if (ImGui::BeginDragDropSource()) { ImGui::SetDragDropPayload("ENT", &id, sizeof(int)); ImGui::Text("%s", x->name.c_str()); ImGui::EndDragDropSource(); }
  if (ImGui::BeginDragDropTarget()) {
    if (auto* p = ImGui::AcceptDragDropPayload("ENT")) scene.SetParent(*(int*)p->Data, id);
    ImGui::EndDragDropTarget();
  }
  if (ImGui::BeginPopupContextItem()) {
    if (ImGui::MenuItem("Añadir hijo")) Create("Empty", id);
    if (ImGui::MenuItem("Duplicar")) Duplicate(id);
    if (ImGui::MenuItem("Eliminar")) del = id;
    ImGui::EndPopup();
  }
  if (open) { for (int k : kids) Tree(k); ImGui::TreePop(); }
}

void Editor::Hierarchy() {
  if (ImGui::Begin("Hierarchy")) {
    if (ImGui::Button("+ Añadir")) ImGui::OpenPopup("addent");
    if (ImGui::BeginPopup("addent")) { CreateMenu(); ImGui::EndPopup(); }
    ImGui::Separator();
    std::vector<int> roots;
    for (auto& x : scene.e) if (x.parent < 0 || !scene.Find(x.parent)) roots.push_back(x.id);
    for (int id : roots) Tree(id);
    ImGui::InvisibleButton("##rootdrop", ImVec2(-1, std::max(24.f, ImGui::GetContentRegionAvail().y)));
    if (ImGui::IsItemClicked()) sel = -1;
    if (ImGui::BeginDragDropTarget()) {
      if (auto* p = ImGui::AcceptDragDropPayload("ENT")) scene.SetParent(*(int*)p->Data, -1);
      ImGui::EndDragDropTarget();
    }
    if (del >= 0) { scene.Remove(del); if (!scene.Find(sel)) sel = -1; del = -1; }
  }
  ImGui::End();
}

void Editor::Inspector() {
  if (ImGui::Begin("Inspector")) {
    Entity* x = scene.Find(sel);
    if (!x) ImGui::TextDisabled("Nada seleccionado");
    else {
      ImGui::PushID(x->id);
      char nb[128]; std::strncpy(nb, x->name.c_str(), 127); nb[127] = 0;
      if (ImGui::InputText("Nombre", nb, 128)) x->name = nb;
      ImGui::Checkbox("Activo", &x->active);
      if (ImGui::CollapsingHeader("Transform", ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::DragFloat3("Posición", &x->pos.x, .05f); ImGui::DragFloat3("Rotación", &x->rot.x, .5f);
        ImGui::DragFloat3("Escala", &x->scl.x, .02f);
        if (ImGui::Button("Resetear")) { x->pos = glm::vec3(0); x->rot = glm::vec3(0); x->scl = glm::vec3(1); }
      }
      std::vector<std::string> meshes, texs, clips, anims;
      for (auto& kv : assets.models) if (kv.first != "Quad") meshes.push_back(kv.first);
      for (auto& kv : assets.tex) texs.push_back(kv.first);
      for (auto& kv : assets.audio) clips.push_back(kv.first);
      for (auto& kv : assets.anims) anims.push_back(kv.first);
      std::vector<std::string> scripts = ScriptManager::Names();
      bool keep = true;

      if (x->hasMesh) {
        keep = true;
        if (ImGui::CollapsingHeader("Mesh Renderer", &keep, ImGuiTreeNodeFlags_DefaultOpen)) {
          Combo("Malla", x->mesh, meshes, false);
          Combo("Textura (todas)", x->tex, texs, true);
          ImGui::ColorEdit4("Color", &x->color.x);
          Model* md = assets.GetModel(x->mesh);
          if (md && !md->subs.empty()) {
            ImGui::TextDisabled("%zu submallas (máx. %d texturas por modelo)", md->subs.size(), kMaxTextures);
            x->subTex.resize(md->subs.size());
            for (size_t k = 0; k < md->subs.size(); k++) {
              ImGui::PushID((int)k);
              Combo(("Submalla " + std::to_string(k)).c_str(), x->subTex[k], texs, true);
              ImGui::PopID();
            }
          }
        }
        if (!keep) x->hasMesh = false;
      }
      if (x->hasSprite) {
        keep = true;
        if (ImGui::CollapsingHeader("Sprite Renderer (2D)", &keep, ImGuiTreeNodeFlags_DefaultOpen)) {
          Combo("Imagen", x->sprite, texs, true); ImGui::ColorEdit4("Tinte", &x->sprColor.x);
        }
        if (!keep) x->hasSprite = false;
      }
      if (x->hasCamera) {
        keep = true;
        if (ImGui::CollapsingHeader("Cámara", &keep, ImGuiTreeNodeFlags_DefaultOpen)) {
          ImGui::Checkbox("Ortográfica (2D)", &x->ortho);
          if (x->ortho) ImGui::DragFloat("Tamaño orto", &x->orthoSize, .05f, .1f, 100);
          else ImGui::SliderFloat("FOV", &x->fov, 10, 120);
        }
        if (!keep) x->hasCamera = false;
      }
      if (x->hasLight) {
        keep = true;
        if (ImGui::CollapsingHeader("Luz direccional", &keep, ImGuiTreeNodeFlags_DefaultOpen)) {
          ImGui::ColorEdit3("Color", &x->lightColor.x); ImGui::SliderFloat("Intensidad", &x->intensity, 0, 4);
        }
        if (!keep) x->hasLight = false;
      }
      if (x->hasAudio) {
        keep = true;
        if (ImGui::CollapsingHeader("Audio Source", &keep, ImGuiTreeNodeFlags_DefaultOpen)) {
          Combo("Clip", x->clip, clips, true);
          ImGui::Checkbox("Bucle", &x->loop); ImGui::Checkbox("Al iniciar", &x->playOnStart);
          ImGui::SliderFloat("Volumen", &x->volume, 0, 1);
          if (ImGui::Button("Probar") && assets.audio.count(x->clip)) Audio::Play(assets.audio[x->clip], false, x->volume);
          ImGui::SameLine(); if (ImGui::Button("Parar todo")) Audio::StopAll();
        }
        if (!keep) x->hasAudio = false;
      }
      if (x->hasCollider) {
        keep = true;
        if (ImGui::CollapsingHeader("Collider", &keep, ImGuiTreeNodeFlags_DefaultOpen)) {
          const char* kinds[] = { "Caja", "Esfera" };
          ImGui::Combo("Forma", &x->colKind, kinds, 2);
          if (x->colKind == 0) ImGui::DragFloat3("Tamaño", &x->colSize.x, .05f, .01f, 1000);
          else ImGui::DragFloat("Radio", &x->colRadius, .02f, .01f, 1000);
        }
        if (!keep) x->hasCollider = false;
      }
      if (x->hasBody) {
        keep = true;
        if (ImGui::CollapsingHeader("Rigidbody", &keep, ImGuiTreeNodeFlags_DefaultOpen)) {
          ImGui::Checkbox("Estático", &x->bodyStatic); ImGui::SameLine(); ImGui::Checkbox("Sólo 2D", &x->body2D);
          ImGui::DragFloat("Masa", &x->mass, .05f, .01f, 1000);
          ImGui::SliderFloat("Rebote", &x->bounce, 0, 1);
          ImGui::SliderFloat("Fricción", &x->friction, 0, 1);
          ImGui::DragFloat("Escala de gravedad", &x->gravityScale, .02f, -5, 5);
          ImGui::TextDisabled("Velocidad: %.2f  %.2f  %.2f%s", x->vel.x, x->vel.y, x->vel.z, x->grounded ? "  (en suelo)" : "");
          if (ImGui::Button("Quitar velocidad")) x->vel = glm::vec3(0);
        }
        if (!keep) x->hasBody = false;
      }
      if (x->hasAnim) {
        keep = true;
        if (ImGui::CollapsingHeader("Animator", &keep, ImGuiTreeNodeFlags_DefaultOpen)) {
          Combo("Clip", x->animClip, anims, true);
          ImGui::DragFloat("Velocidad", &x->animSpeed, .02f, -5, 5);
          ImGui::Checkbox("Bucle", &x->animLoop); ImGui::SameLine(); ImGui::Checkbox("Al jugar", &x->animAutoPlay);
          ImGui::TextDisabled("Tiempo: %.2f s  (edita clips en el panel Animation)", x->animTime);
        }
        if (!keep) x->hasAnim = false;
      }
      if (!x->script.empty()) {
        keep = true;
        if (ImGui::CollapsingHeader("Script", &keep, ImGuiTreeNodeFlags_DefaultOpen)) {
          Combo("Comportamiento", x->script, scripts, false);
          ImGui::DragFloat3("Parámetros", &x->sparam.x, .1f);
        }
        if (!keep) x->script.clear();
      }

      ImGui::Separator();
      if (ImGui::Button("Añadir componente", ImVec2(-1, 0))) ImGui::OpenPopup("addc");
      if (ImGui::BeginPopup("addc")) {
        if (ImGui::MenuItem("Mesh Renderer")) { x->hasMesh = true; }
        if (ImGui::MenuItem("Sprite Renderer (2D)")) x->hasSprite = true;
        if (ImGui::MenuItem("Cámara")) x->hasCamera = true;
        if (ImGui::MenuItem("Luz direccional")) x->hasLight = true;
        if (ImGui::MenuItem("Audio Source")) x->hasAudio = true;
        if (ImGui::MenuItem("Collider")) x->hasCollider = true;
        if (ImGui::MenuItem("Rigidbody")) { x->hasBody = true; x->hasCollider = true; }
        if (ImGui::MenuItem("Animator")) x->hasAnim = true;
        if (ImGui::MenuItem("Script")) { if (!scripts.empty()) x->script = scripts[0]; }
        ImGui::EndPopup();
      }
      ImGui::PopID();
    }
  }
  ImGui::End();
}

void Editor::Project() {
  if (ImGui::Begin("Project")) {
    ImGui::SetNextItemWidth(-150);
    ImGui::InputTextWithHint("##imp", "ruta del archivo a importar (o arrastra)", importPath, sizeof importPath);
    ImGui::SameLine(); if (ImGui::Button("Importar")) { assets.Import(importPath); importPath[0] = 0; }
    ImGui::SameLine(); if (ImGui::Button("Refrescar")) assets.Scan();
    ImGui::SetNextItemWidth(160);
    ImGui::InputTextWithHint("##ns", "nombre de script", newScript, sizeof newScript);
    ImGui::SameLine();
    if (ImGui::Button("Nuevo script") && newScript[0]) {
      if (ScriptManager::CreateTemplate(newScript)) { Log(std::string("Creado Scripts/") + newScript + ".cpp"); ScriptManager::Poll(); }
      newScript[0] = 0;
    }
    ImGui::TextDisabled("%s", assets.dir.c_str()); ImGui::Separator();
    for (auto& f : assets.files) {
      std::string k = Assets::Kind(f); ImGui::PushID(f.c_str());
      const char* tag = k == "texture" ? "[IMG] " : k == "model" ? "[3D]  " : k == "audio" ? "[SND] " :
                        k == "anim" ? "[ANI] " : k == "scene" ? "[SCN] " : "      ";
      ImGui::Selectable((std::string(tag) + f).c_str());
      if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(0)) {
        if (k == "audio") Audio::Play(assets.audio[f], false, 1.f);
        if (k == "anim") editClip = f;
        if (k == "scene" && LoadScene(scene, assets.dir + "/" + f)) { scenePath = f; sel = -1; }
      }
      if (ImGui::BeginDragDropSource()) { ImGui::SetDragDropPayload("ASSET", f.c_str(), f.size() + 1); ImGui::Text("%s", f.c_str()); ImGui::EndDragDropSource(); }
      ImGui::PopID();
    }
    ImGui::Separator();
    ImGui::TextDisabled("Scripts: edita Scripts/*.cpp; se recompila sólo al guardar.");
  }
  ImGui::End();
}

void Editor::Console() {
  if (ImGui::Begin("Console")) {
    if (ImGui::Button("Limpiar")) LogBuf().clear();
    ImGui::Separator(); ImGui::BeginChild("##log");
    for (auto& l : LogBuf()) ImGui::TextUnformatted(l.c_str());
    if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY()) ImGui::SetScrollHereY(1.f);
    ImGui::EndChild();
  }
  ImGui::End();
}

void Editor::AnimPanel() {
  if (ImGui::Begin("Animation")) {
    std::vector<std::string> ak; for (auto& kv : assets.anims) ak.push_back(kv.first);
    Combo("Clip", editClip, ak, true);
    ImGui::SameLine();
    ImGui::SetNextItemWidth(140); ImGui::InputTextWithHint("##nc", "nombre nuevo", newClip, sizeof newClip);
    ImGui::SameLine();
    if (ImGui::Button("Crear") && newClip[0]) {
      std::string n = std::string(newClip) + ".anim";
      if (!assets.anims.count(n)) { AnimClip c; c.name = newClip; assets.anims[n] = c; editClip = n; }
      newClip[0] = 0;
    }
    ImGui::SameLine();
    auto it = assets.anims.find(editClip);
    if (ImGui::Button("Guardar") && it != assets.anims.end()) {
      Anim::Save(it->second, assets.dir + "/" + editClip); assets.Scan(); Log("Clip guardado: " + editClip);
    }
    if (it == assets.anims.end()) { ImGui::TextDisabled("Crea o elige un clip. Aplica el clip con el Animator del objeto."); ImGui::End(); return; }

    AnimClip& c = it->second;
    Entity* x = scene.Find(sel);
    ImGui::DragFloat("Duración (s)", &c.duration, .05f, .1f, 600);
    if (ImGui::SliderFloat("Tiempo", &editTime, 0, c.duration) && x && !playing) ApplyClip(*x, c, editTime);
    const char* eases[] = { "Lineal", "Suave", "Escalón" };
    ImGui::Combo("Interpolación", &easeNew, eases, 3);
    ImGui::TextDisabled("Pulsa un botón para guardar el estado actual del objeto seleccionado en el tiempo elegido:");
    ImGui::BeginDisabled(!x || playing);
    auto addKey = [&](int p, glm::vec4 v) { Anim::InsertKey(Anim::Ensure(c, p), editTime, v, easeNew); };
    if (ImGui::Button("+ Posición") && x) addKey(P_POS, glm::vec4(x->pos, 0));
    ImGui::SameLine(); if (ImGui::Button("+ Rotación") && x) addKey(P_ROT, glm::vec4(x->rot, 0));
    ImGui::SameLine(); if (ImGui::Button("+ Escala") && x) addKey(P_SCL, glm::vec4(x->scl, 0));
    ImGui::SameLine(); if (ImGui::Button("+ Color") && x) addKey(P_COL, x->color);
    ImGui::EndDisabled();
    ImGui::Separator();
    for (size_t t = 0; t < c.tracks.size(); t++) {
      Track& tr = c.tracks[t];
      ImGui::PushID((int)t);
      if (ImGui::TreeNodeEx(Anim::PropName(tr.prop), ImGuiTreeNodeFlags_DefaultOpen)) {
        int del = -1;
        for (size_t k = 0; k < tr.keys.size(); k++) {
          const Key& key = tr.keys[k];
          ImGui::PushID((int)k);
          ImGui::Text("t=%.2f  (%.2f, %.2f, %.2f, %.2f)", key.t, key.v.x, key.v.y, key.v.z, key.v.w);
          ImGui::SameLine(); if (ImGui::SmallButton("x")) del = (int)k;
          ImGui::PopID();
        }
        if (del >= 0) tr.keys.erase(tr.keys.begin() + del);
        ImGui::TreePop();
      }
      ImGui::PopID();
    }
  }
  ImGui::End();
}

void Editor::SceneView() {
  if (ImGui::Begin("Scene", nullptr, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse)) {
    ImGuiIO& io = ImGui::GetIO();
    if (ImGui::RadioButton("Mano", tool == 0)) tool = 0; ImGui::SameLine();
    if (ImGui::RadioButton("Mover", tool == 1)) tool = 1; ImGui::SameLine();
    if (ImGui::RadioButton("Rotar", tool == 2)) tool = 2; ImGui::SameLine();
    if (ImGui::RadioButton("Escalar", tool == 3)) tool = 3; ImGui::SameLine();
    ImGui::Checkbox("Desplazar", &pan); ImGui::SameLine(); ImGui::Checkbox("Local", &local);
    ImVec2 av = ImGui::GetContentRegionAvail();
    if (av.x >= 8 && av.y >= 8) {
      sceneFbo.Resize((int)av.x, (int)av.y);
      float yr = glm::radians(yaw), pr = glm::radians(pitch);
      glm::vec3 eye = target + dist * glm::vec3(std::cos(pr) * std::sin(yr), std::sin(pr), std::cos(pr) * std::cos(yr));
      glm::mat4 view = glm::lookAt(eye, target, glm::vec3(0, 1, 0));
      glm::mat4 proj = glm::perspective(glm::radians(60.f), av.x / av.y, .05f, 1000.f);
      sceneFbo.Bind(); rend.Draw(scene, assets, view, proj, true); glBindFramebuffer(GL_FRAMEBUFFER, 0);
      ImGui::Image((ImTextureID)(intptr_t)sceneFbo.tex, av, ImVec2(0, 1), ImVec2(1, 0));
      bool hovered = ImGui::IsItemHovered();
      ImVec2 p0 = ImGui::GetItemRectMin(), sz = ImGui::GetItemRectSize();
      if (ImGui::BeginDragDropTarget()) {
        if (auto* p = ImGui::AcceptDragDropPayload("ASSET")) SpawnAsset((const char*)p->Data, glm::vec3(0));
        ImGui::EndDragDropTarget();
      }
      ImGuizmo::SetOrthographic(false); ImGuizmo::SetDrawlist(); ImGuizmo::SetRect(p0.x, p0.y, sz.x, sz.y);
      Entity* x = scene.Find(sel);
      if (x && tool > 0 && !playing) {
        ImGuizmo::OPERATION op = tool == 1 ? ImGuizmo::TRANSLATE : tool == 2 ? ImGuizmo::ROTATE : ImGuizmo::SCALE;
        glm::mat4 w = scene.World(*x);
        ImGuizmo::Manipulate(glm::value_ptr(view), glm::value_ptr(proj), op, local ? ImGuizmo::LOCAL : ImGuizmo::WORLD, glm::value_ptr(w));
        if (ImGuizmo::IsUsing()) {
          glm::mat4 pw(1); if (x->parent >= 0) { Entity* p = scene.Find(x->parent); if (p) pw = scene.World(*p); }
          scene.SetLocalFromMatrix(*x, glm::inverse(pw) * w);
        }
      }
      if (hovered && !ImGuizmo::IsUsing()) {
        if (io.MouseWheel != 0) dist = std::max(.5f, dist * std::pow(.9f, io.MouseWheel));
        bool nav = ImGui::IsMouseDown(1) || ImGui::IsMouseDown(2) || (tool == 0 && ImGui::IsMouseDown(0));
        if (nav) {
          if (pan || io.KeyShift || ImGui::IsMouseDown(2)) {
            glm::mat4 inv = glm::inverse(view);
            target += (-glm::vec3(inv[0]) * io.MouseDelta.x + glm::vec3(inv[1]) * io.MouseDelta.y) * dist * .0015f;
          } else { yaw -= io.MouseDelta.x * .4f; pitch = glm::clamp(pitch + io.MouseDelta.y * .4f, -89.f, 89.f); }
        }
        if (!io.WantTextInput) {
          if (ImGui::IsKeyPressed(ImGuiKey_Q)) tool = 0; if (ImGui::IsKeyPressed(ImGuiKey_W)) tool = 1;
          if (ImGui::IsKeyPressed(ImGuiKey_E)) tool = 2; if (ImGui::IsKeyPressed(ImGuiKey_R)) tool = 3;
        }
        if (tool > 0 && ImGui::IsMouseClicked(0) && !ImGuizmo::IsOver()) {
          float nx = (io.MousePos.x - p0.x) / sz.x * 2 - 1, ny = 1 - (io.MousePos.y - p0.y) / sz.y * 2;
          glm::mat4 inv = glm::inverse(proj * view);
          glm::vec4 a = inv * glm::vec4(nx, ny, -1, 1), b = inv * glm::vec4(nx, ny, 1, 1);
          glm::vec3 o = glm::vec3(a) / a.w, d = glm::normalize(glm::vec3(b) / b.w - o);
          int best = -1; float bt = 1e30f;
          for (auto& e : scene.e) {
            if (!e.active) continue; glm::mat4 W = scene.World(e); float r = .4f;
            float sc = std::max({ glm::length(glm::vec3(W[0])), glm::length(glm::vec3(W[1])), glm::length(glm::vec3(W[2])) });
            if (e.hasMesh) { Model* md = assets.GetModel(e.mesh); if (md) r = md->radius * sc; }
            else if (e.hasSprite) { Texture& t = assets.GetTex(e.sprite); r = (e.sprite.empty() ? 1.f : std::max(t.w, t.h) / 100.f) * .6f * sc; }
            else r = .3f;
            glm::vec3 oc = o - glm::vec3(W[3]); float bq = glm::dot(oc, d), c = glm::dot(oc, oc) - r * r, disc = bq * bq - c;
            if (disc >= 0) { float t = -bq - std::sqrt(disc); if (t < bt) { bt = t; best = e.id; } }
          }
          if (best >= 0) sel = best;
        }
      }
    }
  }
  ImGui::End();
}

void Editor::GameView() {
  if (ImGui::Begin("Game", nullptr, ImGuiWindowFlags_NoScrollbar)) {
    ImVec2 av = ImGui::GetContentRegionAvail();
    if (av.x >= 8 && av.y >= 8) {
      gameFbo.Resize((int)av.x, (int)av.y);
      Entity* cam = nullptr; for (auto& x : scene.e) if (x.active && x.hasCamera) { cam = &x; break; }
      gameFbo.Bind();
      if (cam) { glm::mat4 v, p; CamMatrices(*cam, av.x / av.y, v, p); rend.Draw(scene, assets, v, p, false); }
      else { glClearColor(.08f, .08f, .08f, 1); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); }
      glBindFramebuffer(GL_FRAMEBUFFER, 0);
      ImGui::Image((ImTextureID)(intptr_t)gameFbo.tex, av, ImVec2(0, 1), ImVec2(1, 0));
    }
  }
  ImGui::End();
}
