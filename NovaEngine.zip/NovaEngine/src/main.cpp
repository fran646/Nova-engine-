#include <SDL.h>
#include <string>
#include <filesystem>
#include "GL.h"
#include "imgui.h"
#include "imgui_impl_sdl2.h"
#include "imgui_impl_opengl3.h"
#include "ImGuizmo.h"
#include "Editor.h"
#include "Audio.h"

int main(int, char**) {
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) != 0) return 1;
  float uiScale = 1.f; std::string base;
#ifdef __ANDROID__
  const char* glsl = "#version 300 es";
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3); SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
  const char* ext = SDL_AndroidGetExternalStoragePath(); base = ext ? ext : "/sdcard"; uiScale = 2.f;
#else
  const char* glsl = "#version 330 core";
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3); SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
  #ifdef __APPLE__
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, SDL_GL_CONTEXT_FORWARD_COMPATIBLE_FLAG);
  #endif
  base = "Project";
#endif
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1); SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
  SDL_Window* win = SDL_CreateWindow("Nova Engine", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1600, 900,
                                     SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
  if (!win) return 1;
  SDL_GLContext ctx = SDL_GL_CreateContext(win); SDL_GL_MakeCurrent(win, ctx); SDL_GL_SetSwapInterval(1);
  if (!LoadGL()) { SDL_Log("Failed to load OpenGL functions"); return 1; }

  IMGUI_CHECKVERSION(); ImGui::CreateContext();
  ImGuiIO& io = ImGui::GetIO();
  io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard | ImGuiConfigFlags_DockingEnable;
  static std::string ini; char* pref = SDL_GetPrefPath("Nova", "NovaEngine");
  if (pref) { ini = std::string(pref) + "imgui.ini"; io.IniFilename = ini.c_str(); SDL_free(pref); }
  ImGui::StyleColorsDark(); ImGui::GetStyle().WindowRounding = 4; ImGui::GetStyle().FrameRounding = 3;
  ImGui::GetStyle().ScaleAllSizes(uiScale); io.FontGlobalScale = uiScale;
  ImGui_ImplSDL2_InitForOpenGL(win, ctx); ImGui_ImplOpenGL3_Init(glsl);

  Audio::Init();
  Editor ed; ed.Init(base);

  bool running = true; Uint64 last = SDL_GetTicks64();
  while (running && !ed.wantQuit) {
    SDL_Event e;
    while (SDL_PollEvent(&e)) {
      ImGui_ImplSDL2_ProcessEvent(&e);
      if (e.type == SDL_QUIT) running = false;
      if (e.type == SDL_DROPFILE) { ed.Import(e.drop.file); SDL_free(e.drop.file); }
    }
    Uint64 now = SDL_GetTicks64(); float dt = (now - last) / 1000.f; last = now;
    ImGui_ImplOpenGL3_NewFrame(); ImGui_ImplSDL2_NewFrame(); ImGui::NewFrame(); ImGuizmo::BeginFrame();
    ed.Frame(dt);
    ImGui::Render();
    int w, h; SDL_GL_GetDrawableSize(win, &w, &h);
    glBindFramebuffer(GL_FRAMEBUFFER, 0); glViewport(0, 0, w, h);
    glClearColor(.1f, .1f, .1f, 1); glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    SDL_GL_SwapWindow(win);
  }
  ed.Shutdown(); Audio::Shutdown();
  ImGui_ImplOpenGL3_Shutdown(); ImGui_ImplSDL2_Shutdown(); ImGui::DestroyContext();
  SDL_GL_DeleteContext(ctx); SDL_DestroyWindow(win); SDL_Quit();
  return 0;
}
