#pragma once
#include "GL.h"
#include "Log.h"
#include <glm/glm.hpp>
#include <vector>
#include <string>
#include <memory>
#include <algorithm>
#include <cstdint>
#include <cstddef>
#include <cmath>

#ifdef __ANDROID__
#define GLSL_HDR "#version 300 es\nprecision highp float;\nprecision highp int;\n"
#else
#define GLSL_HDR "#version 330 core\n"
#endif

struct Vertex { glm::vec3 p, n; glm::vec2 uv; glm::vec4 j = glm::vec4(0), w = glm::vec4(0); };

struct Shader {
  GLuint id = 0;
  bool Build(const char* vs, const char* fs) {
    auto comp = [&](GLenum t, const char* src) {
      const char* s[2] = { GLSL_HDR, src };
      GLuint h = glCreateShader(t); glShaderSource(h, 2, s, nullptr); glCompileShader(h);
      GLint ok = 0; glGetShaderiv(h, GL_COMPILE_STATUS, &ok);
      if (!ok) { char b[1024]; glGetShaderInfoLog(h, 1024, nullptr, b); Log(std::string("Shader error: ") + b); }
      return h; };
    GLuint v = comp(GL_VERTEX_SHADER, vs), f = comp(GL_FRAGMENT_SHADER, fs);
    id = glCreateProgram(); glAttachShader(id, v); glAttachShader(id, f); glLinkProgram(id);
    GLint ok = 0; glGetProgramiv(id, GL_LINK_STATUS, &ok);
    if (!ok) { char b[1024]; glGetProgramInfoLog(id, 1024, nullptr, b); Log(std::string("Link error: ") + b); }
    glDeleteShader(v); glDeleteShader(f); return ok != 0;
  }
  GLint U(const char* n) const { return glGetUniformLocation(id, n); }
};

struct Mesh {
  GLuint vao = 0, vbo = 0, ebo = 0; int count = 0; GLenum mode = GL_TRIANGLES; float radius = 1; glm::vec3 bmin{0}, bmax{0};
  void Create(const std::vector<Vertex>& v, const std::vector<uint32_t>& i, GLenum m = GL_TRIANGLES) {
    mode = m; count = (int)i.size(); radius = 0; bmin = glm::vec3(1e30f); bmax = glm::vec3(-1e30f);
    for (auto& q : v) { radius = std::max(radius, glm::length(q.p)); bmin = glm::min(bmin, q.p); bmax = glm::max(bmax, q.p); }
    glGenVertexArrays(1, &vao); glBindVertexArray(vao);
    glGenBuffers(1, &vbo); glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, v.size() * sizeof(Vertex), v.data(), GL_STATIC_DRAW);
    glGenBuffers(1, &ebo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, i.size() * sizeof(uint32_t), i.data(), GL_STATIC_DRAW);
    for (int a = 0; a < 5; a++) glEnableVertexAttribArray(a);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, p));
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, n));
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, uv));
    glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, j));
    glVertexAttribPointer(4, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, w));
    glBindVertexArray(0);
  }
  void Draw() const { glBindVertexArray(vao); glDrawElements(mode, count, GL_UNSIGNED_INT, nullptr); }
};

struct Texture { GLuint id = 0; int w = 1, h = 1; };
inline Texture MakeTexture(const unsigned char* px, int w, int h) {
  Texture t; t.w = w; t.h = h;
  glGenTextures(1, &t.id); glBindTexture(GL_TEXTURE_2D, t.id);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
  glGenerateMipmap(GL_TEXTURE_2D);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  return t;
}

struct Fbo {
  GLuint fb = 0, tex = 0, rb = 0; int w = 0, h = 0;
  void Resize(int W, int H) {
    if (W < 1 || H < 1 || (W == w && H == h)) return;
    w = W; h = H;
    if (!fb) { glGenFramebuffers(1, &fb); glGenTextures(1, &tex); glGenRenderbuffers(1, &rb); }
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glBindFramebuffer(GL_FRAMEBUFFER, fb);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    glBindRenderbuffer(GL_RENDERBUFFER, rb);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, w, h);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rb);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
  }
  void Bind() const { glBindFramebuffer(GL_FRAMEBUFFER, fb); glViewport(0, 0, w, h); }
};

// ---- Primitives ----
inline std::shared_ptr<Mesh> MakeCube() {
  std::vector<Vertex> v; std::vector<uint32_t> i;
  glm::vec3 N[6] = { {0,0,1},{0,0,-1},{1,0,0},{-1,0,0},{0,1,0},{0,-1,0} };
  for (int f = 0; f < 6; f++) {
    glm::vec3 n = N[f];
    glm::vec3 ref = std::fabs(n.y) > 0.5f ? glm::vec3(0,0,1) : glm::vec3(0,1,0);
    glm::vec3 u = glm::normalize(glm::cross(ref, n)), w = glm::cross(n, u);
    uint32_t b = (uint32_t)v.size();
    v.push_back({ n*.5f - u*.5f - w*.5f, n, {0,0} });
    v.push_back({ n*.5f + u*.5f - w*.5f, n, {1,0} });
    v.push_back({ n*.5f + u*.5f + w*.5f, n, {1,1} });
    v.push_back({ n*.5f - u*.5f + w*.5f, n, {0,1} });
    for (uint32_t k : {0u,1u,2u,0u,2u,3u}) i.push_back(b + k);
  }
  auto m = std::make_shared<Mesh>(); m->Create(v, i); return m;
}
inline std::shared_ptr<Mesh> MakeSphere() {
  std::vector<Vertex> v; std::vector<uint32_t> i; const int S = 32, R = 16; const float PI = 3.14159265f;
  for (int r = 0; r <= R; r++) for (int s = 0; s <= S; s++) {
    float th = PI * r / R, ph = 2 * PI * s / S;
    glm::vec3 n(std::sin(th) * std::cos(ph), std::cos(th), std::sin(th) * std::sin(ph));
    v.push_back({ n * .5f, n, { (float)s / S, (float)r / R } });
  }
  for (int r = 0; r < R; r++) for (int s = 0; s < S; s++) {
    uint32_t a = r * (S + 1) + s, b = a + S + 1;
    for (uint32_t k : { a, b, a+1, a+1, b, b+1 }) i.push_back(k);
  }
  auto m = std::make_shared<Mesh>(); m->Create(v, i); return m;
}
inline std::shared_ptr<Mesh> MakePlane() { // XZ, normal +Y
  std::vector<Vertex> v = { {{-.5f,0,-.5f},{0,1,0},{0,0}}, {{.5f,0,-.5f},{0,1,0},{1,0}}, {{.5f,0,.5f},{0,1,0},{1,1}}, {{-.5f,0,.5f},{0,1,0},{0,1}} };
  auto m = std::make_shared<Mesh>(); m->Create(v, {0,1,2,0,2,3}); return m;
}
inline std::shared_ptr<Mesh> MakeQuad() { // XY, normal +Z, top of image = +Y
  std::vector<Vertex> v = { {{-.5f,-.5f,0},{0,0,1},{0,1}}, {{.5f,-.5f,0},{0,0,1},{1,1}}, {{.5f,.5f,0},{0,0,1},{1,0}}, {{-.5f,.5f,0},{0,0,1},{0,0}} };
  auto m = std::make_shared<Mesh>(); m->Create(v, {0,1,2,0,2,3}); return m;
}

inline std::shared_ptr<Mesh> MakeWireBox() {
  std::vector<Vertex> v; std::vector<uint32_t> i;
  for (int k = 0; k < 8; k++) v.push_back({ { (k & 1) - .5f, ((k >> 1) & 1) - .5f, ((k >> 2) & 1) - .5f }, {0,1,0}, {0,0} });
  for (int k = 0; k < 8; k++) for (int b = 0; b < 3; b++) if (!(k & (1 << b))) { i.push_back(k); i.push_back(k | (1 << b)); }
  auto m = std::make_shared<Mesh>(); m->Create(v, i, GL_LINES); return m;
}
inline std::shared_ptr<Mesh> MakeWireSphere() {
  std::vector<Vertex> v; std::vector<uint32_t> i; const int S = 48; const float PI = 3.14159265f;
  for (int c = 0; c < 3; c++) for (int k = 0; k < S; k++) {
    float a = 2 * PI * k / S, x = std::cos(a) * .5f, y = std::sin(a) * .5f;
    glm::vec3 p = c == 0 ? glm::vec3(x, y, 0) : c == 1 ? glm::vec3(x, 0, y) : glm::vec3(0, x, y);
    uint32_t b = (uint32_t)v.size(); v.push_back({ p, {0,1,0}, {0,0} }); i.push_back(b); i.push_back(c * S + (k + 1) % S);
  }
  auto m = std::make_shared<Mesh>(); m->Create(v, i, GL_LINES); return m;
}
