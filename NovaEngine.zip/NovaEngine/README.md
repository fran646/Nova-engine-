# Nova Engine
Motor 2D/3D en C++17 con editor estilo Unity (Hierarchy, Inspector, Scene, Game, Project, Console).
SDL2 + OpenGL 3.3 / GLES 3.0, Dear ImGui (docking) + ImGuizmo, glm, tinygltf (.glb/.gltf), stb_image (png/jpg/bmp/tga), miniaudio (wav/mp3/ogg/flac).

## PC (Windows / Linux / macOS)
Requisitos: CMake 3.20+, compilador C++17, git, internet (la 1ª vez descarga las dependencias).
    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build --config Release
    ./build/NovaEditor        (Windows: build\Release\NovaEditor.exe)
Linux: sudo apt install build-essential cmake git libx11-dev libxext-dev libxrandr-dev libxi-dev libxcursor-dev libgl1-mesa-dev libasound2-dev libpulse-dev

## Uso
- Importar: arrastra archivos a la ventana, o escribe la ruta en el panel Project > Import. Se copian a Project/Assets.
- Arrastra un asset del panel Project a la vista Scene para crear un objeto (imagen -> Sprite 2D, .glb -> malla 3D, audio -> Audio Source).
- Scene: clic derecho = orbitar, rueda = zoom, Shift/botón central = desplazar. Q/W/E/R = Mano/Mover/Rotar/Escalar.
- Play/Stop en la barra superior (el estado se restaura al parar). File > Save Scene guarda Main.scene.
- 2D: Cámara con "Orthographic" + objetos Sprite. 3D: Cámara en perspectiva + Mesh Renderer.
- Scripts: edita Scripts() en src/Editor.cpp y registra tu lambda C++; aparece en el combo Script del Inspector.

## Android
1. Descarga SDL2 2.30.x y copia su carpeta `android-project` (Android Studio).
2. En app/build.gradle añade externalNativeBuild { cmake { path "<ruta>/NovaEngine/CMakeLists.txt" } }
   (ABI arm64-v8a; la librería se llama `main`, SDL2 la carga automáticamente).
3. Para que FetchContent funcione en Android, el proyecto Gradle necesita internet en la primera sincronización.
4. Los assets se leen de /Android/data/<paquete>/files/Assets (cópialos ahí por USB o gestor de archivos y pulsa Refresh).
La UI se escala x2 en Android; el toque funciona como ratón (herramienta Hand para mover la cámara, casilla Pan para desplazar).
